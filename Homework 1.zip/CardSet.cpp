#include "CardSet.h"
#include <iostream>
using namespace std;

CardSet::CardSet()
{
}

bool CardSet::add(unsigned long cardNumber)
{
	if (m_Set.insert(cardNumber)) // if card number is added
		return true;
	return false;
}

int CardSet::size() const
{
	return m_Set.size();
}

void CardSet::print() const
{
	for (int i = 0; i < size(); i++)
	{
		ItemType val = m_Set.get(i, val);
		cout << val << endl;
	}
}
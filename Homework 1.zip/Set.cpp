#include "Set.h"
#include <iostream>
using namespace std;

Set::Set()
{
	m_size = 0;
}

bool Set::empty() const
{
	if (m_size == 0)
		return true;
	return false;
}

int Set::size() const
{
	return m_size;
}

bool Set::insert(const ItemType& value)
{
	if (m_size == DEFAULT_MAX_ITEMS) // cannot add anymore values to full array
		return false;
	for (int i = 0; i < m_size; i++) // iterate through array
	{
		if (value == m_arr[i]) // if value is in the array
			return false;
	}
	for (int i = 0; i < m_size; i++) // sort in alpha order
	{
		if (m_arr[i] > value)
		{
			for (int j = m_size; j > i; j--)
			{
				m_arr[j] = m_arr[j - 1];
			}
			m_arr[i] = value;
			m_size++;
			return true;
		}
	}

	m_arr[m_size] = value; // setting next element to value
	m_size++; // increment size
	return true;
}

bool Set::erase(const ItemType& value)
{
	int position = -1;
	for (int i = 0; i < m_size; i++) // iterate through array to find where value is
	{
		if (value == m_arr[i]) // if value is found
		{
			position = i; // set position to where value is found
			break; // exit for loop
		}	
	}

	if (position == -1)
		return false;

	for (int j = position; j < m_size - 1; j++) // iterate through array starting at value
	{
		m_arr[j] = m_arr[j + 1]; // shift all values down
	}
	m_size--; // decrement size of array

	return true;
}

bool Set::contains(const ItemType& value) const
{
	for (int i = 0; i < m_size; i++) // iterate through array
	{
		if (value == m_arr[i]) // if value is in the array
			return true;
	}
	return false;
}

bool Set::get(int i, ItemType& value) const
{
	if (i < 0 || i >= m_size) // if i is between 0 and the array size
		return false;

	value = m_arr[i];
	return true;
}

void Set::swap(Set& other)
{
	ItemType temp[DEFAULT_MAX_ITEMS];

	int tempSize = m_size;
	for (int i = 0; i < m_size; i++)
	{
		get(i, temp[i]); // copying array elements into temp array
	}

	m_size = other.size();
	for (int i = 0; i < other.size(); i++)
	{
		m_arr[i] = other.m_arr[i]; // copy other array into original array
	}

	other.m_size = tempSize;
	for (int i = 0; i < tempSize; i++)
	{
		other.m_arr[i] = temp[i]; // copy temp array into other array
	}
}

void Set::dump() const
{
	for (int i = 0; i < m_size; i++)
	{
		cerr << m_arr[i] << ", ";
	}
}
#include "newSet.h"
#include <iostream>
#include <cstdlib>
using namespace std;

Set::Set() : m_size(0), m_arrmax(DEFAULT_MAX_ITEMS)
{
	m_arr = new ItemType[DEFAULT_MAX_ITEMS];
}

Set::~Set()
{
	delete[] m_arr;
}

Set::Set(int value) : m_size(0)
{
	if (value < 0)
	{
		exit(1);
	}
	m_arrmax = value;
	m_arr = new ItemType[value];
}

Set& Set::operator= (const Set& value)
{
	if (this == &value)
		return *this;

	delete[] m_arr;
	m_size = value.m_size;
	m_arrmax = value.m_arrmax;
	m_arr = new ItemType[m_arrmax];

	for (int i = 0; i < size(); i++)
	{
		m_arr[i] = value.m_arr[i];
	}
	return *this;
}

Set::Set(const Set& other)
{
	m_size = other.m_size;
	m_arrmax = other.m_arrmax;
	m_arr = new ItemType[m_arrmax];

	for (int i = 0; i < size(); i++)
	{
		m_arr[i] = other.m_arr[i];
	}
}

bool Set::empty() const
{
	if (m_size == 0)
		return true;
	return false;
}

int Set::size() const
{
	return m_size;
}

bool Set::insert(const ItemType& value)
{
	if (m_size == DEFAULT_MAX_ITEMS) // cannot add anymore values to full array
		return false;
	for (int i = 0; i < m_size; i++) // iterate through array
	{
		if (value == m_arr[i]) // if value is in the array
			return false;
	}
	for (int i = 0; i < m_size; i++) // sort in alpha order
	{
		if (m_arr[i] > value)
		{
			for (int j = m_size; j > i; j--)
			{
				m_arr[j] = m_arr[j - 1];
			}
			m_arr[i] = value;
			m_size++;
			return true;
		}
	}
	m_arr[m_size] = value; // setting next element to value
	m_size++; // increment size
	return true;
}

bool Set::erase(const ItemType& value)
{
	int position = -1;
	for (int i = 0; i < m_size; i++) // iterate through array to find where value is
	{
		if (value == m_arr[i]) // if value is found
		{
			position = i; // set position to where value is found
			break; // exit for loop
		}
	}

	if (position == -1)
		return false;

	for (int j = position; j < m_size - 1; j++) // iterate through array starting at value
	{
		m_arr[j] = m_arr[j + 1]; // shift all values down
	}
	m_size--; // decrement size of array

	return true;
}

bool Set::contains(const ItemType& value) const
{
	for (int i = 0; i < m_size; i++) // iterate through array
	{
		if (value == m_arr[i]) // if value is in the array
			return true;
	}
	return false;
}

bool Set::get(int i, ItemType& value) const
{
	if (i < 0 || i >= m_size) // if i is between 0 and the array size
		return false;

	value = m_arr[i];
	return true;
}

void Set::swap(Set& other)
{

	int tempSize = other.m_size;
	other.m_size = this->m_size;
	this->m_size = tempSize;

	int tempMax = this->m_arrmax;
	this->m_arrmax = other.m_arrmax;
	other.m_arrmax = tempMax;

	ItemType* tempPointer = this->m_arr;
	this->m_arr = other.m_arr;
	other.m_arr = tempPointer;
}

void Set::dump() const
{
	for (int i = 0; i < m_size; i++)
	{
		cerr << m_arr[i] << ", ";
	}
}
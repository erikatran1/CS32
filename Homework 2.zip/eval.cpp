#include "Set.h"  // with ItemType being a type alias for char
#include <iostream>
#include <string>
#include <stack>
#include <cctype>
#include <cassert>
using namespace std;

int precedence(char ch)
{
	switch (ch)
	{
		case '!': // highest precedence
			return 3; 
		case '&':
			return 2;
		case '|':
			return 1;
		default:
			return 4;
	}
}

int isTrue(char ch, const Set& trueValues, const Set& falseValues)
{
	if (trueValues.contains(ch) && !falseValues.contains(ch)) // if character is in true values and not false
		return 1;
	else if (falseValues.contains(ch) && !trueValues.contains(ch)) // if character is in false values and not true
		return 0;
	else if (trueValues.contains(ch) && falseValues.contains(ch)) // character in both true and false set
		return 3;
	else //if (!trueValues.contains(ch) && !falseValues.contains(ch)) // character in neither sets
		return 2;
}

bool validInfix(string infix, const Set& trueValues, const Set& falseValues)
{
	if (infix == "") // if empty
		return false;

	string newInfix = ""; // creating new infix stirng with no spaces
	for (int i = 0; i < infix.size(); i++)
	{
		if (infix[i] != ' ')
		{
			newInfix += infix[i]; // add values to new string if it is not space
		}
	}
	infix = newInfix; // setting infix to new infix string

	for (int i = 0; i < infix.size(); i++)
	{
		char ch = infix[i];
		if (!isalpha(ch) && ch != '!' && ch != '&' && ch != '|' && ch != '(' && ch != ')')
		{
			return false;
		}
	}

	switch (infix[0]) // if starts with invalid symbol
	{
	case '&':
	case '|':
	case ')':
		return false;
	default:
		break;
	}

	switch (infix[infix.size() - 1]) // if ends with invalid symbol
	{
	case '&':
	case '|':
	case '(':
	case '!':
		return false;
	default:
		break;
	}

	int openPar = 0;
	int closedPar = 0;

	for (int i = 0; i < infix.size(); i++)
	{
		char ch = infix[i];

		if (isupper(ch))
		{
			return false;
		}
			
		if (i + 1 < infix.size())
		{
			if (isalpha(ch) && islower(ch))
			{
				if (isalpha(infix[i + 1]) && islower(infix[i + 1])) // two consecutive letters
				{
					return false;
				}
					
				else if (infix[i + 1] == '!') // exclamation following letter
				{
					return false;
				}

				else if (infix[i + 1] == '(') // open parenthasis following letter
				{
					return false;
				}	
			}
			if (ch == ')' && isalpha(infix[i + 1]))
			{
				return false;
			}
		}

		switch (ch)
		{
		case '(':
			openPar++;
		case '!':
			if (i + 1 < infix.size())
			{
				switch (infix[i + 1])
				{
				case ')':
				case '&':
				case '|':
					return false;
				default:
					break;
				}
			}
			break;
		case '&':
		case '|':
			if (i + 1 < infix.size())
			{
				switch (infix[i + 1])
				{
				case '&':
				case '|':
				case ')':
					return false;
				default:
					break;
				}
			}
			break;
		case ')':
			closedPar++;
			if (i + 1 < infix.size())
			{
				switch (infix[i + 1])
				{
				case '!':
					return false;
				default:
					break;
				}
			}
			break;
		}
		if (openPar < closedPar)
			return false;
	}
	if (openPar != closedPar)
	{
		return false;
	}
	return true;
}

void infixToPostfix(string infix, string& postfix)
{
	postfix = ""; // empty postfix string
	stack<char> operators; // empty character stack

	string newInfix = ""; // creating new infix stirng with no spaces
	for (int i = 0; i < infix.size(); i++)
	{
		if (infix[i] != ' ')
		{
			newInfix += infix[i]; // add values to new string if it is not space
		}
	}
	infix = newInfix; // setting infix to new infix string

	for (int i = 0; i < infix.size(); i++)
	{
		char ch = infix[i];

		if (isalpha(ch) && islower(ch)) // operand
			postfix += ch;

		else if (ch == '(')
			operators.push(ch);

		else if (ch == ')')
		{
			while (operators.top() != '(')
			{
				postfix += operators.top();
				operators.pop();
			}
			operators.pop();
		}

		else // operator
		{
			while (!operators.empty() && operators.top() != '(' && precedence(ch) <= precedence(operators.top()))
			{
				postfix += operators.top();
				operators.pop();
			}
			operators.push(ch);
		}
	}
	while (!operators.empty())
	{
		postfix += operators.top();
		operators.pop();
	}
}

bool postfixEvaluation(string postfix, const Set& trueValues, const Set& falseValues)
{
	stack<bool> operands; // stack of booleans

	for (int i = 0; i < postfix.size(); i++)
	{
		char ch = postfix[i];

		if (isalpha(ch) && islower(ch)) // operand
		{
			if (isTrue(ch, trueValues, falseValues) == 1)
				operands.push(true);
			else if (isTrue(ch, trueValues, falseValues) == 0)
				operands.push(false);
		}

		else if (ch == '!') // not operator
		{
			bool top = operands.top();
			operands.pop();
			operands.push(!top);
		}

		else if (ch == '&' || ch == '|') // and or or operator
		{
			bool operand2 = operands.top();
			operands.pop();
			bool operand1 = operands.top();
			operands.pop();
			switch (ch)
			{
				case '&':
					operands.push(operand1 && operand2);
					break;
				case '|':
					operands.push(operand1 || operand2);
					break;
			}
		}
	}
	return operands.top();
}

int evaluate(string infix, const Set& trueValues, const Set& falseValues, string& postfix, bool& result)
{
	for (int i = 0; i < infix.size(); i++)
	{
		char ch = infix[i];
		if (isalpha(ch))
		{
			if (isTrue(ch, trueValues, falseValues) == 3)
				return 3;
			else if (isTrue(ch, trueValues, falseValues) == 2)
				return 2;
		}

	}
	if (!validInfix(infix, trueValues, falseValues))
		return 1;

	infixToPostfix(infix, postfix);
	result = postfixEvaluation(postfix, trueValues, falseValues);

	return 0;
}

int main()
{
	string trueChars = "tywz";
	string falseChars = "fnx";
	Set trues;
	Set falses;
	for (int k = 0; k < trueChars.size(); k++)
		trues.insert(trueChars[k]);
	for (int k = 0; k < falseChars.size(); k++)
		falses.insert(falseChars[k]);

	string pf;
	bool answer;
	assert(evaluate("w| f", trues, falses, pf, answer) == 0 && pf == "wf|" && answer);
	assert(evaluate("y|", trues, falses, pf, answer) == 1);
	assert(evaluate("n t", trues, falses, pf, answer) == 1);
	assert(evaluate("nt", trues, falses, pf, answer) == 1);
	assert(evaluate("()", trues, falses, pf, answer) == 1);
	assert(evaluate("()z", trues, falses, pf, answer) == 1);
	assert(evaluate("y(n|y)", trues, falses, pf, answer) == 1);
	assert(evaluate("t(&n)", trues, falses, pf, answer) == 1);
	assert(evaluate("(n&(t|y)", trues, falses, pf, answer) == 1);
	assert(evaluate("n+y", trues, falses, pf, answer) == 1);
	assert(evaluate("", trues, falses, pf, answer) == 1);
	assert(evaluate("f  |  !f & (t&n) ", trues, falses, pf, answer) == 0
		&& pf == "ff!tn&&|" && !answer);
	assert(evaluate(" x  ", trues, falses, pf, answer) == 0 && pf == "x" && !answer);
	trues.insert('x');
	assert(evaluate("((x))", trues, falses, pf, answer) == 3);
	falses.erase('x');
	assert(evaluate("((x))", trues, falses, pf, answer) == 0 && pf == "x" && answer);
	trues.erase('w');
	
	//cout << isTrue('w', trues, falses);
	//cout << evaluate("d| f", trues, falses, pf, answer);
	assert(evaluate("w| f", trues, falses, pf, answer) == 2); // FIX
	falses.insert('w');
	assert(evaluate("w| f", trues, falses, pf, answer) == 0 && pf == "wf|" && !answer);
	cout << "Passed all tests" << endl;

}


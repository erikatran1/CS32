#include <queue>
#include <string>
#include <iostream>
using namespace std;

class Coord
{
public:
    Coord(int r, int c) : m_row(r), m_col(c) {}
    int r() const { return m_row; }
    int c() const { return m_col; }
private:
    int m_row;
    int m_col;
};

bool pathExists(string maze[], int nRows, int nCols, int sr, int sc, int er, int ec);
// Return true if there is a path from (sr,sc) to (er,ec)
// through the maze; return false otherwise

int main()
{
    string maze[10] = {
                "XXXXXXXXXX",
                "X..X...X.X",
                "X.XXXX.X.X",
                "X.X.X..X.X",
                "X...X.XX.X",
                "XXX......X",
                "X.X.XXXX.X",
                "X.XXX....X",
                "X...X..X.X",
                "XXXXXXXXXX"
    };

    if (pathExists(maze, 10, 10, 5, 3, 8, 8))
        cout << "Solvable!" << endl;
    else
        cout << "Out of luck!" << endl;
}

bool pathExists(string maze[], int nRows, int nCols, int sr, int sc, int er, int ec)
{
    if (!(sr >= 0 && sr < nRows) || !(sc >= 0 && sc < nCols))
        return false;

    queue<Coord> coordQueue; // queue of coordinates
    Coord start(sr, sc);
    coordQueue.push(start); // pushes starting coordinates on queue
    maze[sr][sc] = '0';

    while (!coordQueue.empty())
    {
        Coord cur = coordQueue.front(); // cur to front coordinates
        int curR = cur.r();
        int curC = cur.c();
        cout << "(" << curR << ", " << curC << ")" << endl;
        coordQueue.pop(); // remove from queue
        
        if (curR == er && curC == ec) // if current point is ending point
            return true;

        if (maze[curR][curC + 1] == '.') // can go east
        {
            coordQueue.push(Coord(curR, curC + 1));
            maze[curR][curC + 1] = '0';
        }

        if (maze[curR - 1][curC] == '.') // can go north
        {
            coordQueue.push(Coord(curR - 1, curC));
            maze[curR - 1][curC] = '0';
        }

        if (maze[curR][curC - 1] == '.') // can go west
        {
            coordQueue.push(Coord(curR, curC - 1));
            maze[curR][curC - 1] = '0';
        }

        if (maze[curR + 1][curC] == '.') // can go south
        {
            coordQueue.push(Coord(curR + 1, curC));
            maze[curR + 1][curC] = '0';
        }
    }
    return false;
}
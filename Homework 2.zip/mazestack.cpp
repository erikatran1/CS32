#include <stack>
#include <string>
#include <iostream>
using namespace std;

class Coord
{
public:
    Coord(int r, int c) : m_row(r), m_col(c) {}
    int r() const { return m_row; }
    int c() const { return m_col; }
private:
    int m_row;
    int m_col;
};

bool pathExists(string maze[], int nRows, int nCols, int sr, int sc, int er, int ec);
// Return true if there is a path from (sr,sc) to (er,ec)
// through the maze; return false otherwise

int main()
{
    string maze[10] = {
        "XXXXXXXXXX",
        "X..X...X.X",
        "X.XXXX.X.X",
        "X.X.X..X.X",
        "X...X.XX.X",
        "XXX......X",
        "X.X.XXXX.X",
        "X.XXX....X",
        "X...X..X.X",
        "XXXXXXXXXX"
    };

    if (pathExists(maze, 10, 10, 5, 3, 8, 8))
        cout << "Solvable!" << endl;
    else
        cout << "Out of luck!" << endl;
}

bool pathExists(string maze[], int nRows, int nCols, int sr, int sc, int er, int ec)
{
    if (!(sr >= 0 && sr < nRows) || !(sc >= 0 && sc < nCols))
        return false;

    stack<Coord> coordStack; // stack of coordinates
    Coord start(sr, sc);
    coordStack.push(start); // pushes starting coordinates on stack
    maze[sr][sc] = '0'; // updates starting piont on maze

    while (!coordStack.empty()) // while stack is not empty
    {
        Coord cur = coordStack.top(); // cur to top coordinates
        int curR = cur.r();
        int curC = cur.c();
        cout << "(" << curR << ", " << curC << ")" << endl;
        coordStack.pop(); // remove from stack

        
        if (curR == er && curC == ec) // if current point is ending point
            return true;

        if (maze[curR][curC + 1] == '.' && maze[curR][curC + 1]!= 'X') // can go east
        {
            coordStack.push(Coord(curR, curC + 1));
            maze[curR][curC + 1] = '0';
        }

        if (maze[curR - 1][curC] == '.' && maze[curR - 1][curC] != 'X') // can go north
        {
            coordStack.push(Coord(curR - 1, curC));
            maze[curR - 1][curC] = '0';
        }

        if (maze[curR][curC - 1] == '.' && maze[curR][curC - 1] != 'X') // can go west
        {
            coordStack.push(Coord(curR, curC - 1));
            maze[curR][curC - 1] = '0';
        }

        if (maze[curR + 1][curC] == '.' && maze[curR + 1][curC] != 'X') // can go south
        {
            coordStack.push(Coord(curR + 1, curC));
            maze[curR + 1][curC] = '0';
        }
    }
    return false;
}

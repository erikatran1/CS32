void listAll(string path, const File* f)  // two-parameter overload
{
    if (f->files() == nullptr || f->files()->empty())
    {
        return;
    }

    if (path == f->name())
        cout << (path + "/") << endl;

    vector<File*>::const_iterator it;
    for (it = f->files()->begin(); it != f->files()->end(); it++)
    {
        string name = (*it)->name();
        if (name.size() > 4 && name[name.size() - 4] == '.')
            cout << (path + "/" + name) << endl;
        else
            cout << (path + "/" + name + "/") << endl;
        listAll(path + "/" + name, *it);
    }
}
#include "History.h"
#include "globals.h"
#include <iostream>
using namespace std;

History::History(int nRows, int nCols)
{
	m_nRows = nRows;
	m_nCols = nCols;
	for (int r = 1; r <= nRows; r++)
	{
		for (int c = 1; c <= nCols; c++)
		{
			m_space[r-1][c-1] = '.';
		}
	}
}

bool History::record(int r, int c)
{
	if (r < 1 || r > m_nRows || c < 1 || c > m_nCols)
		return false;

	if (m_space[r-1][c-1] == '.')
	{
		m_space[r-1][c-1] = 'A';
	}
	else if (m_space[r-1][c-1] >= 'A' && m_space[r-1][c-1] <= 'Y')
	{
		m_space[r-1][c-1]++;
	}
	return true;
}

void History::display() const
{
	clearScreen();
	for (int r = 1; r <= m_nRows; r++)
	{
		for (int c = 1; c <= m_nCols; c++)
		{
			cout << m_space[r - 1][c - 1];
		}
		cout << endl;
	}
	cout << endl;
}
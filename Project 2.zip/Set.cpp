#include "Set.h"
#include <iostream>
using namespace std;

Set::Set()
{
	numNodes = 0;
	head = nullptr;
	tail = nullptr;
}

Set::~Set()
{
	if (head == nullptr) // empty list
		return;

	Node* p;
	p = head; // p points to head item
	while (p != nullptr)
	{
		Node* n = p->next; // temporary variable to hold next value
		delete p;
		p = n; // set p to temporary n value
	}
}

Set& Set::operator= (const Set& value)
{
	if (this != &value)
	{
		Set temp(value); // temporary set with value inside
		swap(temp); // swap values then temp deleted
	}
	return *this;
}

Set::Set(const Set& other)
{
	numNodes = other.numNodes;

	if (other.numNodes == 0) // if other is empty
	{
		head = nullptr;
		tail = nullptr;
		numNodes = 0;
		return;
	}

	head = new Node; // new linked list
	head->prev = nullptr;

	Node* p = head; // pointer to head
	Node* c = other.head; // pointer to other's head

	while (c->next != nullptr)
	{
		Node* newNode = new Node; // creating next node
		p->value = c->value; // sets node to same value
		p->next = newNode; // sets next node as new node
		newNode->prev = p; // next node's previous is p

		p = newNode; // p is now the next node
		c = c->next; // increment c

	}
	p->value = c->value; // copies last value into p
	tail = p;
	p->next = nullptr; // sets last node to nullptr
}


bool Set::empty() const
{
	if (head == nullptr)
		return true;
	return false;
}

int Set::size() const
{
	return numNodes;
}

bool Set::insert(const ItemType& value)
{
	Node* p = new Node;

	if (head == nullptr)
	{
		p->value = value; // set new node value to value
		p->next = nullptr; // set new node next to nullptr
		p->prev = nullptr;

		head = p; // head now points to this new node
		tail = p;

		numNodes++;
		return true;
	}

	Node* n = head; // set n back to beginning of list
	while (n != nullptr) // iterate through entire linked list
	{
		if (n->value == value) // if list value is value
			return false;
		n = n->next;
	}

	if (value < head->value) // if value needs to be placed at beginning of list
	{
		p->value = value; // setting new node's value to value
		p->next = head; // set p's next to the head, so p becomes first
		p->prev = nullptr; // set p's prev to nullptr because is first
		head->prev = p; // setting head's prev to p
		head = p; // p is the new head

		numNodes++;
		return true;
	}

	if (value > tail->value) // if value needs to be placed at end of list
	{
		p->value = value; // setting new node's value to value
		p->next = nullptr; // set p's next to nullptr
		p->prev = tail; // set p's prev to tail
		tail->next = p;
		tail = p; // p is the new tail

		numNodes++;
		return true;
	}

	n = head;
	while (n != nullptr) // iterate through list
	{
		if (n->next->value > value) // sort in alphabetical order
		{
			break;
		}
		n = n->next;
	}

	p->value = value; // setting new node's value to value
	p->next = n->next; // setting n's next to p's next
	p->prev = n; // setting n's prev to address of p
	Node* t = n->next;
	n->next = p;
	t->prev = p; // setting the node after p's prev to p


	numNodes++;
	return true;
}

bool Set::erase(const ItemType& value)
{
	if (head == nullptr) // empty list
		return false;

	if (!contains(value))
		return false;

	if (numNodes == 1)
	{
		Node* n = head;
		head = nullptr;
		tail = nullptr;
		delete n;
		numNodes--;
		return true;
	}

	if (head->value == value) // if first value is value
	{
		Node* n = head; // p points to head
		head = n->next; // set head to the next value
		head->prev = nullptr;
		delete n;

		numNodes--;
		return true;
	}

	if (tail->value == value) // if value is last
	{
		Node* n = tail;
		tail = n->prev;
		tail->next = nullptr;
		delete n;

		numNodes--;
		return true;
	}

	Node* p = head;
	while (p != nullptr) // iterate through entire linked list
	{
		if (p->next != nullptr && p->next->value == value) // p pointing to node above value
		{
			break;
		}
		p = p->next;
	}

	if (p != nullptr) // will execute if we found our value
	{
		Node* n = p->next; // hold the address of item we want to erase
		p->next = n->next; // sets p's next to the value after item we want to erase
		n->next->prev = p;
		delete n;

		numNodes--;
		return true;
	}
	return false; // if nothing was erased
}

bool Set::contains(const ItemType& value) const
{
	Node* p = head;

	while (p != nullptr) // iterate through entire linked list
	{
		if (p->value == value) // if p's value is value
			return true;
		p = p->next; // iterate to next node
	}

	return false; // if no value is found
}

bool Set::get(int pos, ItemType& value) const
{
	if (pos >= numNodes || pos < 0) // if position is out of bounds
		return false;

	Node* p = head;
	int i = 1;
	while (i <= pos) // iterate until position point
	{
		p = p->next; // point to next node
		i++; // increment i value
	}
	value = p->value; // set value to the value of p
	return true;
}

void Set::swap(Set& other)
{
	int tempNodes = numNodes; // temp value holding number of nodes
	numNodes = other.numNodes;
	other.numNodes = tempNodes;

	Node* tempHead = head;
	head = other.head;
	other.head = tempHead;

	Node* tempTail = tail;
	tail = other.tail;
	other.tail = tempTail;
}

void unite(const Set& s1, const Set& s2, Set& result)
{
	Set res; // new set

	for (int i = 0; i < s1.size(); i++) // iterate through s1
	{
		ItemType item;
		s1.get(i, item); // get value and copy into item
		res.insert(item); // insert item into new set
	}

	for (int i = 0; i < s2.size(); i++) // iterate though s2
	{
		ItemType item;
		s2.get(i, item); // get value and copy into item
		res.insert(item); // insert item into set
	}

	result = res;

}

void butNot(const Set& s1, const Set& s2, Set& result)
{
	Set res; // new set

	for (int i = 0; i < s1.size(); i++) // iterate through s1
	{
		ItemType item;
		s1.get(i, item); // get value and copy into item
		if (!s2.contains(item)) // if the value is not in s2
			res.insert(item);
	}

	result = res;
}

void Set::dump() const
{
	Node* p = head;
	while (p != nullptr) {
		if (p->prev == nullptr) {
			cout << "null           *** ";
		}
		else {
			cout << p->prev << " *** ";
		}
		cout << "  " << p << " *** ";
		if (p->next == nullptr) {
			cout << "null           *** ";
		}
		else {
			cout << p->next << " *** ";
		}
		p = p->next;
		cout << endl << endl;
	}

	cout << "number of nodes: " << numNodes << endl << endl;
	p = head;
	while (p != nullptr)
	{
		cout << p->value << " ";
		p = p->next;
	}

	cout << endl;

}
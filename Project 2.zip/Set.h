#ifndef SET
#define SET
#include <string>

using ItemType = std::string;

struct Node
{
    ItemType value;
    Node* next;
    Node* prev;
};

class Set
{
public:
    Set();         // Create an empty set (i.e., one whose size() is 0).

    ~Set();

    Set& operator= (const Set& value);

    Set(const Set& other);

    bool empty() const;  // Return true if the set is empty, otherwise false.

    int size() const;    // Return the number of items in the set.

    bool insert(const ItemType& value);
    // Insert value into the set if it is not already present.  Return
    // true if the value is actually inserted.  Leave the set unchanged
    // and return false if value is not inserted (perhaps because it
    // was already in the set or because the set has a fixed capacity and
    // is full).

    bool erase(const ItemType& value);
    // Remove the value from the set if it is present.  Return true if the
    // value was removed; otherwise, leave the set unchanged and
    // return false.

    bool contains(const ItemType& value) const;
    // Return true if the value is in the set, otherwise false.

    bool get(int pos, ItemType& value) const;
    // If 0 <= i < size(), copy into value the item in the set that is
    // strictly greater than exactly i items in the set and return true.
    // Otherwise, leave value unchanged and return false.

    void swap(Set& other);
    // Exchange the contents of this set with the other one.

    void dump() const;
    // Print infomration about the set


private:
    Node* head;
    Node* tail;
    int numNodes;
};

void unite(const Set& s1, const Set& s2, Set& result);
// Copies all values of s1 and s2 into result, printing like numbers only once

void butNot(const Set& s1, const Set& s2, Set& result);
// Copies all values in s1 but not in s2, placing set in result

#endif

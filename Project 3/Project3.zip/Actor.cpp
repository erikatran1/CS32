#include "Actor.h"
#include "StudentWorld.h"
#include <iostream>
#include <cstdlib>
using namespace std;

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

void Player::doSomething()
{
	if (m_waitingToRoll == 1)
	{
		if (getWalkingDir() != right && getWalkingDir() != left &&
			getWalkingDir() != up && getWalkingDir() != down)
		{
			setWalkingDir(randDir(getX(), getY()));
			if (getWalkingDir() == left)
				setDirection(left);
			else
				setDirection(right);
		}
		switch (getWorld()->getAction(m_playerNum))
		{
		case ACTION_NONE:
			break;
		case ACTION_ROLL:
			m_die = randInt(1, 10);
			setTicks(m_die * 8);
			m_waitingToRoll = 2;
			break;
		case ACTION_FIRE:
			if (getVortex())
			{
				getWorld()->shootVortex(getX(), getY(), getWalkingDir());
				getWorld()->playSound(SOUND_PLAYER_FIRE);
				setVortex(false);
			}
			break;
		default:
			setNewPlayer(false);
			return;
		}
		setNewPlayer(false);
	}
	else if (m_waitingToRoll == 2) // walking
	{
		int newX, newY;
		if (fork(getX(), getY(), getWalkingDir()) && !isCorner(getX(), getY()) && getWorld()->checkSquare(getX(), getY()))
		{
			switch (getWorld()->getAction(m_playerNum))
			{
			case ACTION_LEFT:
				getPositionInThisDirection(left, SPRITE_WIDTH, newX, newY);
				if (isValidPos(newX, newY) && getWalkingDir() != right)
				{
					setWalkingDir(left);
					setDirection(left);
				}
				break;
			case ACTION_RIGHT:
				getPositionInThisDirection(right, SPRITE_WIDTH, newX, newY);
				if (isValidPos(newX, newY) && getWalkingDir() != left)
				{
					setWalkingDir(right);
					setDirection(right);
				}
				break;
			case ACTION_UP:
				getPositionInThisDirection(left, SPRITE_WIDTH, newX, newY);
				if (isValidPos(newX, newY) && getWalkingDir() != down)
				{
					setWalkingDir(up);
					setDirection(right);
				}
				break;
			case ACTION_DOWN:
				getPositionInThisDirection(left, SPRITE_WIDTH, newX, newY);
				if (isValidPos(newX, newY) && getWalkingDir() != up)
				{
					setWalkingDir(down);
					setDirection(right);
				}
				break;
			default:
				return;
			}
		}
		if (getWalkingDir() == left || getWalkingDir() == right)
			getPositionInThisDirection(getWalkingDir(), SPRITE_WIDTH, newX, newY);
		else
			getPositionInThisDirection(getWalkingDir(), SPRITE_HEIGHT, newX, newY);
		if (!(isValidPos(newX, newY)))
		{
			if (newX % SPRITE_WIDTH == 0 && newY % SPRITE_HEIGHT == 0)
			{
				if (getWalkingDir() == right || getWalkingDir() == left)
				{
					if (isValidPos(getX(), getY() + SPRITE_HEIGHT))
					{
						setWalkingDir(up);
						setDirection(right);
					}
					else if (isValidPos(getX(), getY() - SPRITE_HEIGHT))
					{
						setWalkingDir(down);
						setDirection(right);
					}
				}
				else if (getWalkingDir() == up || getWalkingDir() == down)
				{
					if (isValidPos(getX() + SPRITE_WIDTH, getY()))
					{
						setWalkingDir(right);
						setDirection(right);
					}
					else if (isValidPos(getX() - SPRITE_WIDTH, getY()))
					{
						setWalkingDir(left);
						setDirection(left);
					}
				}
			}
		}

			// move two pixels in walk direction
			moveAtAngle(getWalkingDir(), 2);
			if (getX() % SPRITE_WIDTH == 0 && getY() % SPRITE_HEIGHT == 0)
				m_die--;
			// decrement ticks_to_move count by 1
			setTicks(getTicks() - 1);
			if (getTicks() == 0)
			{
				m_waitingToRoll = 1;
				setNewPlayer(true);
			}
	}
}

void Baddie::doSomething()
{
	if (m_paused)
	{
		int rand = randInt(1, 2);
		if (m_baddieNum == 1 && (getWorld()->playerOverlap(getX(), getY()) > 0)) //bowser and player on same square && player in waiting to roll state
		{
			if (getWorld()->playerOverlap(getX(), getY() == 3) && getWorld()->playerWaitingToRoll(3) == 1 && 
				getWorld()->getNewPlayer(1) && getWorld()->getNewPlayer(2)) // 
				{
					if (rand == 1)
					{
						getWorld()->changePlayerCoins(3, getWorld()->getPlayerCoins(3));
						getWorld()->playSound(SOUND_BOWSER_ACTIVATE);
					}
				}
			else if ((getWorld()->playerOverlap(getX(), getY() == 1) && getWorld()->playerWaitingToRoll(1) == 1 && getWorld()->getNewPlayer(1)) ||
				getWorld()->playerOverlap(getX(), getY()) == 3 && getWorld()->playerWaitingToRoll(1) == 1 && getWorld()->getNewPlayer(1))
			{
				if (rand == 1)
				{
					getWorld()->changePlayerCoins(1, getWorld()->getPlayerCoins(1));
					getWorld()->playSound(SOUND_BOWSER_ACTIVATE);
				}
			}
			else if ((getWorld()->playerOverlap(getX(), getY() == 2) && getWorld()->playerWaitingToRoll(2) == 1 && getWorld()->getNewPlayer(2) || 
				getWorld()->playerOverlap(getX(), getY()) == 3 && getWorld()->playerWaitingToRoll(2) == 1 && getWorld()->getNewPlayer(2)))
			{
				if (rand == 1)
				{
					getWorld()->changePlayerCoins(2, getWorld()->getPlayerCoins(2));
					getWorld()->playSound(SOUND_BOWSER_ACTIVATE);
				}
			}
			
		}
		if (m_baddieNum == 2 && (getWorld()->playerOverlap(getX(), getY()) > 0)) // boo and player on same square && player in waiting to roll state
		{
			if (getWorld()->playerOverlap(getX(), getY()) == 3 && getWorld()->playerWaitingToRoll(3) == 1 &&
				getWorld()->getNewPlayer(1) && getWorld()->getNewPlayer(2))
			{
				switch (rand)
				{
				case 1:
					getWorld()->swapCoins();
					break;
				case 2:
					getWorld()->swapStars();
					break;
				}
				getWorld()->playSound(SOUND_BOO_ACTIVATE);
				switch (randInt(1, 2))
				{
				case 1:
					getWorld()->swapCoins();
					break;
				case 2:
					getWorld()->swapStars();
					break;
				}
				getWorld()->playSound(SOUND_BOO_ACTIVATE);
			}
			else if ((getWorld()->playerOverlap(getX(), getY()) == 1 && getWorld()->playerWaitingToRoll(1) == 1 && getWorld()->getNewPlayer(1)) ||
				(getWorld()->playerOverlap(getX(), getY()) == 3 && getWorld()->playerWaitingToRoll(1) == 1 && getWorld()->getNewPlayer(1))) // peach
			{
				switch (rand)
				{
				case 1:
					getWorld()->swapCoins();
					break;
				case 2:
					getWorld()->swapStars();
					break;
				}
				getWorld()->playSound(SOUND_BOO_ACTIVATE);
			}
			else if ((getWorld()->playerOverlap(getX(), getY()) == 2 && getWorld()->playerWaitingToRoll(2) == 1 && getWorld()->getNewPlayer(2)) ||
				(getWorld()->playerOverlap(getX(), getY()) == 3 && getWorld()->playerWaitingToRoll(2) == 1 && getWorld()->getNewPlayer(2)))
			{
				switch (rand)
				{
				case 1:
					getWorld()->swapCoins();
					break;
				case 2:
					getWorld()->swapStars();
					break;
				}
				getWorld()->playSound(SOUND_BOO_ACTIVATE);
			}
			
		}
		m_pauseCounter--;
		if (m_pauseCounter == 0)
		{
			if (m_baddieNum == 1)
				m_squares_to_move = randInt(1, 10);
			else if (m_baddieNum == 2)
				m_squares_to_move = randInt(1, 3);
			setTicks(m_squares_to_move * 8);
			setWalkingDir(randDir(getX(), getY()));
			if (getWalkingDir() == left)
				setDirection(left);
			else
				setDirection(right);
			m_paused = false;
			setNewPlayer(false);
		}
	}
	
	else // walking state
	{
		if (isValidPos(getX(), getY()) && fork(getX(), getY(), getWalkingDir()))
		{
			setWalkingDir(randDir(getX(), getY()));
			if (getWalkingDir() == left)
				setDirection(left);
			else
				setDirection(right);
		}
		else
		{
			int newX, newY;
			getPositionInThisDirection(getWalkingDir(), 16, newX, newY);
			if (isValidPos(getX(), getY()) && !isValidPos(newX, newY))
			{
				if (newX % SPRITE_WIDTH == 0 && newY % SPRITE_HEIGHT == 0)
				{
					if (getWalkingDir() == right || getWalkingDir() == left)
					{
						if (isValidPos(getX(), getY() + SPRITE_HEIGHT))
						{
							setWalkingDir(up);
							setDirection(right);
						}
						else if (isValidPos(getX(), getY() - SPRITE_HEIGHT))
						{
							setWalkingDir(down);
							setDirection(right);
						}
					}
					else if (getWalkingDir() == up || getWalkingDir() == down)
					{
						if (isValidPos(getX() + SPRITE_WIDTH, getY()))
						{
							setWalkingDir(right);
							setDirection(right);
						}
						else if (isValidPos(getX() - SPRITE_WIDTH, getY()))
						{
							setWalkingDir(left);
							setDirection(left);
						}
					}
				}
			}
		}
		moveAtAngle(getWalkingDir(), 2);
		setTicks(getTicks() - 1);
		if (getTicks() == 0)
		{
			m_paused = true;
			m_pauseCounter = 180;
			if (m_baddieNum == 1)
			{
				if (randInt(1, 4) == 1)
				{
					/*Bowser will deposit a dropping by asking the StudentWorld
					object to remove the square underneath him and insert a
					new Dropping Square in its place*/
					getWorld()->removeSquare(getX(), getY(), this); // fix
					getWorld()->playSound(SOUND_DROPPING_SQUARE_CREATED);
				}
			}
			setNewPlayer(true);
		}
	}
}

void CoinSquare::doSomething()
{
	if (!getAlive())
	{
		return;
	}
	if (getWorld()->getNewPlayer(1) || getWorld()->getNewPlayer(2))
	{
		if (m_squareNum == 1) // blue coin square
		{ 
			if (getWorld()->playerOverlap(getX(), getY()) == 3 && getWorld()->getNewPlayer(3) && getWorld()->playerWaitingToRoll(3) == 1)
			{
				getWorld()->changePlayerCoins(3, 3);
				getWorld()->playSound(SOUND_GIVE_COIN);
			}
			else if ((getWorld()->playerOverlap(getX(), getY()) == 1 && getWorld()->getNewPlayer(1) && getWorld()->playerWaitingToRoll(1) == 1 ||
				getWorld()->playerOverlap(getX(), getY()) == 3 && getWorld()->getNewPlayer(1) && getWorld()->playerWaitingToRoll(1) == 1)) // peach
			{
				getWorld()->changePlayerCoins(1, 3);
				getWorld()->playSound(SOUND_GIVE_COIN);
			}
			else if ((getWorld()->playerOverlap(getX(), getY()) == 2 && getWorld()->getNewPlayer(2) && getWorld()->playerWaitingToRoll(2) == 1 ||
				getWorld()->playerOverlap(getX(), getY()) == 3 && getWorld()->getNewPlayer(2) && getWorld()->playerWaitingToRoll(2) == 1)) // yoshi
			{
				getWorld()->changePlayerCoins(2, 3);
				getWorld()->playSound(SOUND_GIVE_COIN);
			}
		}
		else if (m_squareNum == 2) // red coin square
		{
			if (getWorld()->playerOverlap(getX(), getY()) == 3 && getWorld()->getNewPlayer(3) && getWorld()->playerWaitingToRoll(3) == 1)
			{
				getWorld()->changePlayerCoins(3, -3);
				getWorld()->playSound(SOUND_TAKE_COIN);
			}
			else if ((getWorld()->playerOverlap(getX(), getY()) == 1 && getWorld()->getNewPlayer(1) && getWorld()->playerWaitingToRoll(1) == 1 ||
				getWorld()->playerOverlap(getX(), getY()) == 3 && getWorld()->getNewPlayer(1) && getWorld()->playerWaitingToRoll(1) == 1)) // peach
			{
				getWorld()->changePlayerCoins(1, -3);
				getWorld()->playSound(SOUND_TAKE_COIN);
			}
			else if ((getWorld()->playerOverlap(getX(), getY()) == 2 && getWorld()->getNewPlayer(2) && getWorld()->playerWaitingToRoll(2) == 1 ||
				getWorld()->playerOverlap(getX(), getY()) == 3 && getWorld()->getNewPlayer(2) && getWorld()->playerWaitingToRoll(2) == 1)) // yoshi
			{
				getWorld()->changePlayerCoins(2, -3);
				getWorld()->playSound(SOUND_TAKE_COIN);
			}
		}
	}
}

void StarSquare::doSomething()
{
	int num = getWorld()->playerOverlap(getX(), getY());
	if (num > 0 || (getWorld()->getNewPlayer(num) && getWorld()->playerWaitingToRoll(num)))
	{
		if (num == 1)
		{
			if (getWorld()->getPlayerCoins(1) < 20)
				return;
			else
			{
				getWorld()->changePlayerCoins(1, -20);
				getWorld()->changePlayerStars(1, 1);
				getWorld()->playSound(SOUND_GIVE_STAR);
			}
		}
		else if (num == 2)
		{
			if (getWorld()->getPlayerCoins(2) < 20)
				return;
			else
			{
				getWorld()->changePlayerCoins(2, -20);
				getWorld()->changePlayerStars(2, 1);
				getWorld()->playSound(SOUND_GIVE_STAR);
			}
		}
		else if (num == 3)
		{
			if (getWorld()->getPlayerCoins(1) < 20) { }
			else
			{
				getWorld()->changePlayerCoins(1, -20);
				getWorld()->changePlayerStars(1, 1);
				getWorld()->playSound(SOUND_GIVE_STAR);
			}
			if (getWorld()->getPlayerCoins(2) < 20) { }
			else
			{
				getWorld()->changePlayerCoins(2, -20);
				getWorld()->changePlayerStars(2, 1);
				getWorld()->playSound(SOUND_GIVE_STAR);
			}
		}

	}
}

void DirectionSquare::doSomething()
{
	int num = getWorld()->playerOverlap(getX(), getY());
	if (num > 0)
	{
		getWorld()->setWalkingDir(num, getDir());
	}
}

void BankSquare::doSomething()
{
	int num = getWorld()->playerOverlap(getX(), getY());
	if (num > 0 && getWorld()->getNewPlayer(num) && getWorld()->playerWaitingToRoll(num) == 1)
	{
		getWorld()->withdrawBank(num);
		getWorld()->playSound(SOUND_WITHDRAW_BANK);
		getWorld()->notNew(num);
	}
	else if (num > 0)
	{
		if (getWorld()->getPlayerCoins(num) < 5)
		{
			getWorld()->changePlayerCoins(num, -getWorld()->getPlayerCoins(num));
			getWorld()->depositBank(getWorld()->getPlayerCoins(num));
			getWorld()->playSound(SOUND_DEPOSIT_BANK);
		}
		else
		{
			getWorld()->changePlayerCoins(num, -5);
			getWorld()->depositBank(5);
			getWorld()->playSound(SOUND_DEPOSIT_BANK);
		}
	}
}

void EventSquare::doSomething()
{
	int num = getWorld()->playerOverlap(getX(), getY());
	int rand = randInt(1, 3);
	if (num > 0 && getWorld()->getNewPlayer(num) && getWorld()->playerWaitingToRoll(num) == 1)
	{
		switch (rand)
		{
		case 1:
			getWorld()->teleport(num, getX(), getY());
			getWorld()->playSound(SOUND_PLAYER_TELEPORT);
			break;
		case 2:
			getWorld()->swapAll();
			if (getWorld()->playerOverlap(getX(), getY() == 1))
				getWorld()->notNew(1);
			else if (getWorld()->playerOverlap(getX(), getY() == 2))
				getWorld()->notNew(2);
			getWorld()->playSound(SOUND_PLAYER_TELEPORT);
			break;
		case 3:
			getWorld()->giveVortex(num);
			getWorld()->playSound(SOUND_GIVE_VORTEX);
			break;
		}
	}
}

void DroppingSquare::doSomething()
{
	int rand = randInt(1, 2);
	int i = 0;
	int playerNum = getWorld()->playerOverlap(getX(), getY());
	if (playerNum == 1 || playerNum == 2) { i = 1; }
	for (; i < 2; i++)
	{
		if (getWorld()->getNewPlayer(playerNum) && playerNum > 0)
		{
			switch (rand)
			{
			case 1:
				getWorld()->changePlayerCoins(playerNum, -10);
				break;
			case 2:
				getWorld()->changePlayerStars(playerNum, -1);
			}
			getWorld()->playSound(SOUND_DROPPING_SQUARE_ACTIVATE);
		}
	}
}

void Vortex::doSomething()
{
	if (!m_active)
		return;
	moveAtAngle(getDir(), 2);
	if (getX() < 0 || getX() > VIEW_WIDTH || getY() < 0 || getY() > VIEW_HEIGHT)
	{
		setActive(false);
		getWorld()->deleteVortex();
	}
	if (getWorld()->baddieIntersect(getX(), getY()))
	{
		/*If there are more than one object that the Vortex overlaps with (e.g., two
		Boos on the same square), pick one of them to be hit (it's up to you how to
		pick).
		b. The Vortex object will inform the other object that it has been impacted.
		The impacted object can then decide what to do once it's impacted (each
		object can figure out how to react to being impacted: See the Boo and
		Bowser sections; right now, they teleport themselves).*/
		getWorld()->teleportBaddie(getX(), getY());
		setActive(false);
		getWorld()->playSound(SOUND_HIT_BY_VORTEX);
		getWorld()->deleteVortex();
	}
}

bool Actor::isValidPos(int x, int y)
{
	if (x < 0 || y < 0 || x > VIEW_WIDTH || y > VIEW_HEIGHT) { return false; }
	else if (x % SPRITE_WIDTH != 0 || y % SPRITE_HEIGHT != 0) { return false; }
	x /= SPRITE_WIDTH;
	y /= SPRITE_HEIGHT;
	if (getWorld()->getBoard()->getContentsOf(x, y) == Board::empty) { return false; }

	return true;
}

bool Actor::fork(int x, int y, int dir)
{
	int num = 0;
	int newX, newY;

	getPositionInThisDirection(right, SPRITE_WIDTH, newX, newY);
	if (isValidPos(newX, newY) && dir != left) { num++; }

	getPositionInThisDirection(left, SPRITE_WIDTH, newX, newY);
	if (isValidPos(newX, newY) && dir != right) { num++; }

	getPositionInThisDirection(up, SPRITE_HEIGHT, newX, newY);
	if (isValidPos(newX, newY) && dir != down) { num++; }

	getPositionInThisDirection(down, SPRITE_HEIGHT, newX, newY);
	if (isValidPos(newX, newY) && dir != up) { num++; }
	

	if (num > 1)
		return true;
	return false;
}

bool Actor::isCorner(int x, int y)
{
	if (isValidPos(x + SPRITE_WIDTH, y) && isValidPos(x, y - SPRITE_HEIGHT) && !isValidPos(x - SPRITE_WIDTH, y) && !isValidPos(x, y + SPRITE_HEIGHT))
		return true;
	if (isValidPos(x - SPRITE_WIDTH, y) && isValidPos(x, y - SPRITE_HEIGHT) && !isValidPos(x + SPRITE_WIDTH, y) && !isValidPos(x, y + SPRITE_HEIGHT))
		return true;
	if (isValidPos(x + SPRITE_WIDTH, y) && isValidPos(x, y + SPRITE_HEIGHT) && !isValidPos(x - SPRITE_WIDTH, y) && !isValidPos(x, y - SPRITE_HEIGHT))
		return true;
	if (isValidPos(x - SPRITE_WIDTH, y) && isValidPos(x, y + SPRITE_HEIGHT) && !isValidPos(x + SPRITE_WIDTH, y) && !isValidPos(x, y - SPRITE_HEIGHT))
		return true;
	return false;
}

int MovingCharacters::randDir(int x, int y)
{
	int rand = randInt(1, 4);
	if (rand == 1)
	{
		if (isValidPos(getX() - SPRITE_WIDTH, getY()) && getWalkingDir() != right)
			return left;
		else if (isValidPos(getX() + SPRITE_WIDTH, getY()) && getWalkingDir() != left)
			return right;
		else if (isValidPos(getX(), getY() + SPRITE_HEIGHT) && getWalkingDir() != down)
			return up;
		else if (isValidPos(getX(), getY() - SPRITE_HEIGHT) && getWalkingDir() != up)
			return down;
	}
	else if (rand == 2)
	{
		if (isValidPos(getX(), getY() + SPRITE_HEIGHT) && getWalkingDir() != down)
			return up;
		else if (isValidPos(getX(), getY() - SPRITE_HEIGHT) && getWalkingDir() != up)
			return down;
		else if (isValidPos(getX() + SPRITE_WIDTH, getY()) && getWalkingDir() != left)
			return right;
		else if (isValidPos(getX() - SPRITE_WIDTH, getY()) && getWalkingDir() != right)
			return left;
	}
	else if (rand == 3)
	{
		if (isValidPos(getX(), getY() - SPRITE_HEIGHT) && getWalkingDir() != up)
			return down;
		else if (isValidPos(getX(), getY() + SPRITE_HEIGHT) && getWalkingDir() != down)
			return up;
		else if (isValidPos(getX() - SPRITE_WIDTH, getY()) && getWalkingDir() != right)
			return left;
		else if (isValidPos(getX() + SPRITE_WIDTH, getY()) && getWalkingDir() != left)
			return right;
	}
	else
	{
		if (isValidPos(getX() + SPRITE_WIDTH, getY()) && getWalkingDir() != left)
			return right;
		else if (isValidPos(getX() - SPRITE_WIDTH, getY()) && getWalkingDir() != right)
			return left;
		else if (isValidPos(getX(), getY() - SPRITE_HEIGHT) && getWalkingDir() != up)
			return down;
		else if (isValidPos(getX(), getY() + SPRITE_HEIGHT) && getWalkingDir() != down)
			return up;
	}
	return getWalkingDir();
}

void Actor::teleportPos(int startX, int startY, int &x, int &y)
{
	int randX = randInt(0, VIEW_WIDTH);
	int randY = randInt(0, VIEW_HEIGHT);
	while (!isValidPos(randX, randY) || (randX == startX && randY == startY))
	{
		randX = randInt(0, VIEW_WIDTH);
		randY = randInt(0, VIEW_HEIGHT);
	}
	x = randX;
	y = randY;
}
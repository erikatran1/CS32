#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include <vector>
using namespace std;

class StudentWorld;

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class Actor : public GraphObject
{
public:
	Actor(StudentWorld* w, int imageID, int startX, int startY, int dir = right, int depth = 0, double size = 1.0) :
		GraphObject(imageID, startX, startY, dir, depth, size), m_world(w)
	{ }
	~Actor() { }

	virtual void doSomething() = 0;
	bool isValidPos(int x, int y);
	bool fork(int x, int y, int dir);
	bool isCorner(int x, int y);
	virtual bool isSquare() { return false; }
	virtual bool isValidForkSquare() { return false; };
	virtual bool vortexImpact() { return false; }
	virtual bool isVortex() { return false; }
	void teleportPos(int startX, int startY, int& x, int& y);
	StudentWorld* getWorld() { return m_world; }

	bool getAlive() { return m_alive; }
	void setAlive(bool a) { m_alive = a; }

	int xVal() { return getX(); }
	int yVal() { return getY(); }

private:
	StudentWorld* m_world;
	bool m_alive = true;
};

class MovingCharacters : public Actor
{
public:
	MovingCharacters(StudentWorld* w, int imageID, int startX, int startY) :
		Actor(w, imageID, startX, startY, right, 0, 1.0), m_walkingDir(right)
	{
		m_ticks_to_move = 0;
		m_newPlayer = true;
	}
	void setWalkingDir(int dir) 
	{ 
		m_walkingDir = dir; 
		if (dir == left)
			setDirection(left);
		else
			setDirection(right);
	}
	int getWalkingDir() { return m_walkingDir; }

	void setTicks(int ticks) { m_ticks_to_move = ticks; }
	int getTicks() { return m_ticks_to_move; }

	void setNewPlayer(bool val) { m_newPlayer = val; }
	bool getNewPlayer() { return m_newPlayer; }

	int randDir(int x, int y);

private:
	int m_walkingDir;
	int m_ticks_to_move;
	bool m_newPlayer;
};

class Player : public MovingCharacters
{
public:
	Player(StudentWorld* w, int imageID, int startX, int startY, int playerNum) :
		MovingCharacters(w, imageID, startX, startY), m_playerNum(playerNum)
	{
		m_waitingToRoll = 1; // 1 is waiting, 2 is walking, 3 is fork
		m_coins = 0;
		m_stars = 0;
		m_newPlayer = true;
		m_vortex = false;
	}
	int  getWaitingToRoll() { return m_waitingToRoll; }
	void setWaitingToRoll(int roll) { m_waitingToRoll = roll; }

	int getCoins() { return m_coins; }
	void setCoins(int coins) { m_coins = coins; }

	int getStars() { return m_stars; }
	void setStars(int stars) { m_stars = stars; }

	bool getNewPlayerStatus() { return m_newPlayer; }
	void setNewPlayerStatus(bool status) { m_newPlayer = status; }

	int getDie() { return m_die; }

	bool getVortex() { return m_vortex; }
	void setVortex(bool v) { m_vortex = v; }

	void set_coins(int c) { m_coins = c; }

	virtual void doSomething();

private:
	int m_waitingToRoll;
	bool m_side;
	int m_coins;
	int m_stars;
	int m_die = 0;
	int m_vortex;
	int m_playerNum;
	bool m_newPlayer;
};

class Baddie : public MovingCharacters
{
public:
	Baddie(StudentWorld* w, int imageID, int startX, int startY, int baddieNum) :
		MovingCharacters(w, imageID, startX, startY), m_baddieNum(baddieNum)
	{
		m_paused = true;
	}
	virtual void doSomething();
	virtual bool vortexImpact() { return true; }

private:
	bool m_paused;
	int m_pauseCounter = 180;
	int m_squares_to_move;
	int m_baddieNum;
};

class Square : public Actor
{
public:
	Square(StudentWorld* w, int imageID, int startX, int startY, int dir) :
		Actor(w, imageID, startX, startY, dir, 1, 1.0)
	{ }
	
	virtual bool isSquare() { return true; }

private:
};

class CoinSquare : public Square
{
public:
	CoinSquare(StudentWorld* w, int imageID, int startX, int startY, int squareNum) :
		Square(w, imageID, startX, startY, right), m_squareNum(squareNum)
	{}
	virtual void doSomething();
	virtual bool isValidForkSquare() { return true; }

private:
	int m_squareNum;
};

class StarSquare : public Square
{
public:
	StarSquare(StudentWorld* w, int startX, int startY) :
		Square(w, IID_STAR_SQUARE, startX, startY, right)
	{ }
	virtual void doSomething();
	virtual bool isValidForkSquare() { return true; }

private:
};

class DirectionSquare : public Square
{
public:
	DirectionSquare(StudentWorld* w, int imageID, int startX, int startY, int dir) :
		Square(w, imageID, startX, startY, dir), m_dir(dir)
	{ }
	virtual void doSomething();

	int getDir() { return m_dir; }


private:
	int m_dir;
};

class BankSquare : public Square
{
public:
	BankSquare(StudentWorld* w, int startX, int startY) :
		Square(w, IID_BANK_SQUARE, startX, startY, right)
	{ }
	virtual void doSomething();

	virtual bool isValidForkSquare() { return true; }

private:
};

class EventSquare : public Square
{
public:
	EventSquare(StudentWorld* w, int startX, int startY) :
		Square(w, IID_EVENT_SQUARE, startX, startY, right)
	{ }
	virtual void doSomething();

	virtual bool isValidForkSquare() { return true; }

private:
};

class DroppingSquare : public Square
{
public:
	DroppingSquare(StudentWorld* w, int startX, int startY) :
		Square(w, IID_DROPPING_SQUARE, startX, startY, right)
	{ }

	virtual void doSomething();

	virtual bool isValidForkSquare() { return true; }

private:
};

class Vortex : public Actor
{
public:
	Vortex(StudentWorld* w, int startX, int startY, int dir) : 
		Actor(w, IID_VORTEX, startX, startY, dir, 0, 1), m_dir(dir)
	{ 
		m_active = true;
	}
	
	virtual void doSomething();

	int getDir() { return m_dir; }
	void setActive(bool a) { m_active = a; }
	virtual bool isVortex() { return true; }

private:
	bool m_active;
	int m_dir;
};

#endif // ACTOR_H_

#include "StudentWorld.h"
#include "GameConstants.h"
#include "Actor.h"
#include <string>
#include <sstream>
using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
    return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h, and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
    : GameWorld(assetPath)
{
    m_peach = nullptr;
    m_yoshi = nullptr;
    actors.clear();
}

int StudentWorld::init()
{
    string boardFile = "board0";
    ostringstream oss;
    string boardtxt = to_string(getBoardNumber()) + ".txt";
    oss << boardtxt;
    boardFile += oss.str();
    string board_file = assetPath() + boardFile;


    Board::LoadResult result = m_board.loadBoard(board_file);
    if (result == Board::load_fail_file_not_found)
    {
        cerr << "Could not find board01.txt data file\n";
        return GWSTATUS_BOARD_ERROR;
    }
    else if (result == Board::load_fail_bad_format)
    {
        cerr << "Your board was improperly formatted\n";
        return GWSTATUS_BOARD_ERROR;
    }
    else if (result == Board::load_success) {
        cerr << "Successfully loaded board\n";

        for (int i = 0; i < BOARD_WIDTH; i++)
        {
            for (int j = 0; j < BOARD_HEIGHT; j++)
            {
                int xVal = i * 16;
                int yVal = j * 16;

                Board::GridEntry ge = m_board.getContentsOf(i, j);
                switch (ge)
                {
                case Board::empty:
                    break;
                case Board::player:
                    m_peach = new Player(this, IID_PEACH, xVal, yVal, 1);
                    actors.push_back(new CoinSquare(this, IID_BLUE_COIN_SQUARE, xVal, yVal, 1));
                    m_yoshi = new Player(this, IID_YOSHI, xVal, yVal, 2);
                    break;
                case Board::blue_coin_square:
                    actors.push_back(new CoinSquare(this, IID_BLUE_COIN_SQUARE, xVal, yVal, 1));
                    break;
                case Board::star_square:
                    actors.push_back(new StarSquare(this, xVal, yVal));
                    break;
                case Board::red_coin_square:
                    actors.push_back(new CoinSquare(this, IID_RED_COIN_SQUARE, xVal, yVal, 2));
                    break;
                case Board::left_dir_square:
                    actors.push_back(new DirectionSquare(this, IID_DIR_SQUARE, xVal, yVal, Actor::left));
                    break;
                case Board::right_dir_square:
                    actors.push_back(new DirectionSquare(this, IID_DIR_SQUARE, xVal, yVal, Actor::right));
                    break;
                case Board::up_dir_square:
                    actors.push_back(new DirectionSquare(this, IID_DIR_SQUARE, xVal, yVal, Actor::up));
                    break;
                case Board::down_dir_square:
                    actors.push_back(new DirectionSquare(this, IID_DIR_SQUARE, xVal, yVal, Actor::down));
                    break;
                case Board::bank_square:
                    actors.push_back(new BankSquare(this, xVal, yVal));
                    break;
                case Board::event_square:
                    actors.push_back(new EventSquare(this, xVal, yVal));
                    break;
                case Board::bowser:
                    actors.push_back(new Baddie(this, IID_BOWSER, xVal, yVal, 1));
                    actors.push_back(new CoinSquare(this, IID_BLUE_COIN_SQUARE, xVal, yVal, 1));
                    break;
                case Board::boo:
                    actors.push_back(new Baddie(this, IID_BOO, xVal, yVal, 2));
                    actors.push_back(new CoinSquare(this, IID_BLUE_COIN_SQUARE, xVal, yVal, 1));
                    break;
                default:
                    break;
                }
            }
        }
    }

    startCountdownTimer(99);

    //startCountdownTimer(5);  // this placeholder causes timeout after 5 seconds
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    vector<Actor*>::iterator i = actors.begin();
    while (i != actors.end())
    {
        (*i)->doSomething();
        i++;
    }

    vector<Actor*>::iterator j = actors.begin();
    while (j != actors.end())
    {
        if (!(*j)->getAlive())
        {
            delete* j;
            actors.erase(j);
            j = actors.begin();
        }
        j++;
    }

    m_peach->doSomething();
    m_yoshi->doSomething();

    setGameStatText(text());

    if (timeRemaining() <= 0)
    {
        playSound(SOUND_GAME_FINISHED);
        if ((m_yoshi->getStars() > m_peach->getStars()) ||
            ((m_yoshi->getStars() == m_peach->getStars()) && (m_yoshi->getCoins() > m_peach->getCoins()))) // yoshi won
        {
            setFinalScore(m_yoshi->getStars(), m_yoshi->getCoins());
            return (GWSTATUS_YOSHI_WON);
        }
        if ((m_peach->getStars() > m_yoshi->getStars()) ||
            ((m_peach->getStars() == m_yoshi->getStars()) && (m_peach->getCoins() > m_yoshi->getCoins()))) // peach won
        {
            setFinalScore(m_peach->getStars(), m_peach->getCoins());
            return (GWSTATUS_PEACH_WON);
        }
    }

    return GWSTATUS_CONTINUE_GAME;


    // This code is here merely to allow the game to build, run, and terminate after you hit ESC.
    // Notice that the return value GWSTATUS_NOT_IMPLEMENTED will cause our framework to end the game.

    /*setGameStatText("Game will end in a few seconds");

    if (timeRemaining() <= 0)
        return GWSTATUS_NOT_IMPLEMENTED;

    return GWSTATUS_CONTINUE_GAME;*/
}

void StudentWorld::cleanUp()
{
    if (m_peach != nullptr)
    {
        delete m_peach;
        m_peach = nullptr;
    }
    if (m_yoshi != nullptr)
    {
        delete m_yoshi;
        m_yoshi = nullptr;
    }

    vector<Actor*>::iterator i = actors.begin();
    while (i != actors.end())
    {
        delete(*i);
        i = actors.erase(i);
    }
}

//  P1 Roll: 3 Stars: 2 $$: 15 | Time: 75 | Bank: 9 | P2 Roll: 0 Stars: 1 $$: 22 VOR
// Left P1 = peach
string StudentWorld::text()
{
    stringstream pDie, pStar, pCoin, time, bank, yDie, yStar, yCoin;
    string pDie_, pStar_, pCoin_, time_, bank_, yDie_, yStar_, yCoin_;
    pDie << m_peach->getDie();
    pDie >> pDie_;
    pStar << m_peach->getStars();
    pStar >> pStar_;
    pCoin << m_peach->getCoins();
    pCoin >> pCoin_;
    time << timeRemaining();
    time >> time_;
    bank << m_bank;
    bank >> bank_;
    yDie << m_yoshi->getDie();
    yDie >> yDie_;
    yStar << m_yoshi->getStars();
    yStar >> yStar_;
    yCoin << m_yoshi->getCoins();
    yCoin >> yCoin_;

    string text;

    text = "P1 Roll: " + pDie_ + " Stars: " + pStar_ + " $$: " + pCoin_;
    if (m_peach->getVortex())
    {
        text += " VOR";
    }
    text += " | Time: " + time_ + " | Bank: " + bank_ + " | P2 Roll: " + yDie_ + " Stars: " + yStar_ + " $$: " + yCoin_;
    if (m_yoshi->getVortex())
    {
        text += " VOR";
    }
    return text;
}

int StudentWorld::playerOverlap(int x, int y)
{
    if (m_peach->getX() == x && m_peach->getY() == y && m_yoshi->getX() == x && m_yoshi->getY() == y)
        return 3;
    else if (m_peach->getX() == x && m_peach->getY() == y)
        return 1;
    else if (m_yoshi->getX() == x && m_yoshi->getY() == y)
        return 2;
    return 0;
}

void StudentWorld::setWalkingDir(int playerNum, int dir)
{
    if (playerNum == 1)
    {
        m_peach->setWalkingDir(dir);
    }
    else if (playerNum == 2)
    {
        m_yoshi->setWalkingDir(dir);
    }
    else if (playerNum == 3)
    {
        m_peach->setWalkingDir(dir);
        m_yoshi->setWalkingDir(dir);
    }
}

int StudentWorld::getPlayerCoins(int playerNum)
{
    if (playerNum == 1)
        return m_peach->getCoins();
    else if (playerNum == 2)
        return m_yoshi->getCoins();
}

void StudentWorld::changePlayerCoins(int playerNum, int coins)
{
    if (playerNum == 1)
        m_peach->setCoins(m_peach->getCoins() + coins);
    else if (playerNum == 2)
        m_yoshi->setCoins(m_yoshi->getCoins() + coins);
    else if (playerNum == 3)
    {
        m_peach->setCoins(m_peach->getCoins() + coins);
        m_yoshi->setCoins(m_yoshi->getCoins() + coins);
    }

    if (m_peach->getCoins() < 0)
        m_peach->setCoins(0);

    if (m_yoshi->getCoins() < 0)
        m_yoshi->setCoins(0);
}

int StudentWorld::getPlayerStars(int playerNum)
{
    if (playerNum == 1)
        return m_peach->getStars();
    else if (playerNum == 2)
        return m_yoshi->getStars();
}

void StudentWorld::changePlayerStars(int playerNum, int stars)
{
    if (playerNum == 1)
        m_peach->setStars(m_peach->getStars() + stars);
    else if (playerNum == 2)
        m_yoshi->setStars(m_yoshi->getStars() + stars);
    else if (playerNum == 3)
    {
        m_peach->setStars(m_peach->getStars() + stars);
        m_yoshi->setStars(m_yoshi->getStars() + stars);
    }

    if (m_peach->getStars() < 0)
        m_peach->setStars(0);

    if (m_yoshi->getStars() < 0)
        m_yoshi->setStars(0);
}

bool StudentWorld::playerWaitingToRoll(int playerNum)
{
    if (playerNum == 3 && m_peach->getWaitingToRoll() == 1 && m_yoshi->getWaitingToRoll() == 1)
        return true;
    else if (playerNum == 1 && m_peach->getWaitingToRoll() == 1)
        return true;
    else if (playerNum == 2 && m_yoshi->getWaitingToRoll() == 1)
        return true;
    
    return false;
}

void StudentWorld::swapCoins()
{
    int temp = m_peach->getCoins();
    m_peach->setCoins(m_yoshi->getCoins());
    m_yoshi->setCoins(temp);
}

void StudentWorld::swapStars()
{
    int temp = m_peach->getStars();
    m_peach->setStars(m_yoshi->getStars());
    m_yoshi->setStars(temp);
}

bool StudentWorld::getNewPlayer(int playerNum)
{
    if (playerNum == 1)
        return m_peach->getNewPlayer();
    else if (playerNum == 2)
        return m_yoshi->getNewPlayer();
    else if (playerNum == 3)
        return m_peach->getNewPlayer() && m_yoshi->getNewPlayer();
}

void StudentWorld::removeSquare(int x, int y, Baddie* b)
{
    vector<Actor*>::iterator i = actors.begin();
    while (i != actors.end())
    {
        if ((*i)->xVal() == x && (*i)->yVal() == y && b != (*i) && (*i)->isSquare())
        {
            break;
        }
        i++;
    }
    (*i)->setAlive(false);
    actors.push_back(new DroppingSquare(this, x, y));
}

void StudentWorld::withdrawBank(int playerNum)
{
    if (playerNum == 1)
        m_peach->setCoins(m_bank);
    else if (playerNum == 2)
        m_yoshi->setCoins(m_bank);
  
    m_bank = 0;
}

void StudentWorld::depositBank(int amt)
{
    m_bank += amt;
}

void StudentWorld::swapAll()
{
    int tempX = m_peach->xVal();
    int tempY = m_peach->yVal();
    m_peach->moveTo(m_yoshi->xVal(), m_yoshi->yVal());
    m_yoshi->moveTo(tempX, tempY);

    int tempTicks = m_peach->getTicks();
    m_peach->setTicks(m_yoshi->getTicks());
    m_yoshi->setTicks(tempTicks);

    int tempWDir = m_peach->getWalkingDir();
    m_peach->setWalkingDir(m_yoshi->getWalkingDir());
    m_yoshi->setWalkingDir(tempWDir);

    int tempSDir = m_peach->getDirection();
    m_peach->setWalkingDir(m_yoshi->getDirection());
    m_yoshi->setDirection(tempSDir);

    int tempWalkState = m_peach->getWaitingToRoll();
    m_peach->setWaitingToRoll(m_yoshi->getWaitingToRoll());
    m_yoshi->setWaitingToRoll(tempWalkState);
}

void StudentWorld::giveVortex(int playerNum)
{
    if (playerNum == 1)
    {
        if (!m_peach->getVortex())
            m_peach->setVortex(true);
    }
    else if (playerNum == 2)
    {
        if (!m_yoshi->getVortex())
            m_yoshi->setVortex(true);
    }
    else if (playerNum == 3)
    {
        if (!m_peach->getVortex())
            m_peach->setVortex(true);

        if (!m_yoshi->getVortex())
            m_yoshi->setVortex(true);
    }
}

void StudentWorld::shootVortex(int x, int y, int dir)
{
    if (dir == Actor::right)
        actors.push_back(new Vortex(this, x + SPRITE_WIDTH, y, dir));
    if (dir == Actor::up)
        actors.push_back(new Vortex(this, x, y + SPRITE_HEIGHT, dir));
    if (dir == Actor::left)
        actors.push_back(new Vortex(this, x - SPRITE_WIDTH, y, dir));
    if (dir == Actor::down)
        actors.push_back(new Vortex(this, x, y - SPRITE_HEIGHT, dir));
}

void StudentWorld::notNew(int playerNum)
{
    if (playerNum == 1)
        m_peach->setNewPlayerStatus(false);
    else if (playerNum == 2)
        m_yoshi->setNewPlayerStatus(false);
    else if (playerNum == 3)
    {
        m_peach->setNewPlayerStatus(false);
        m_yoshi->setNewPlayerStatus(false);
    }
}

void StudentWorld::teleport(int playerNum, int x, int y)
{
    int newX, newY;
    if (playerNum == 1)
    {
        m_peach->teleportPos(x, y, newX, newY);
        m_peach->moveTo(newX, newY);
        if (m_peach->isValidPos(newX + SPRITE_WIDTH, newY)) // right
            setWalkingDir(1, Actor::right);
        else if (m_peach->isValidPos(newX, newY - SPRITE_HEIGHT)) // up
            setWalkingDir(1, Actor::up);
        else if (m_peach->isValidPos(newX - SPRITE_WIDTH, newY)) // left
            setWalkingDir(1, Actor::left);
        else if (m_peach->isValidPos(newX, newY + SPRITE_HEIGHT)) // down
            setWalkingDir(1, Actor::down);

    }
    else if (playerNum == 2)
    {
        m_yoshi->teleportPos(x, y, newX, newY);
        m_yoshi->moveTo(newX, newY);
        if (m_yoshi->isValidPos(newX + SPRITE_WIDTH, newY)) // right
            setWalkingDir(2, Actor::right);
        else if (m_yoshi->isValidPos(newX, newY - SPRITE_HEIGHT)) // up
            setWalkingDir(2, Actor::up);
        else if (m_yoshi->isValidPos(newX - SPRITE_WIDTH, newY)) // left
            setWalkingDir(2, Actor::left);
        else if (m_yoshi->isValidPos(newX, newY + SPRITE_HEIGHT)) // down
            setWalkingDir(2, Actor::down);
    }
}

bool StudentWorld::checkSquare(int x, int y)
{
    vector<Actor*>::iterator i = actors.begin();
    while (i != actors.end())
    {
        if ((*i)->xVal() == x && (*i)->yVal() == y)
        {
            return (*i)->isValidForkSquare();
        }
        i++;
    }
    return false;
}

bool StudentWorld::baddieIntersect(int x, int y)
{
    int bxMax = x + SPRITE_WIDTH;
    int bxMin = x;
    int byMax = y + SPRITE_HEIGHT;
    int byMin = y;
    vector<Actor*>::iterator i = actors.begin();
    while (i != actors.end())
    {
        int vxMax = (*i)->xVal() + SPRITE_WIDTH;
        int vxMin = (*i)->xVal();
        int vyMax = (*i)->yVal() + SPRITE_HEIGHT;
        int vyMin = (*i)->yVal();
        if (bxMin <= vxMin && vxMin <= bxMax && bxMax <= vxMax && ((byMin <= vyMin && vyMin <= byMax && byMax <= vyMax) || vyMin <= byMin && byMin <= vyMax && vyMax <= byMax) ||
            vxMin <= bxMin && bxMin <= vxMax && vxMax <= bxMax && ((byMin <= vyMin && vyMin <= byMax && byMax <= vyMax) || vyMin <= byMin && byMin <= vyMax && vyMax <= byMax))
        {
            return (*i)->vortexImpact();
        }
        i++;
    }
}

void StudentWorld::teleportBaddie(int x, int y)
{
    vector<Actor*>::iterator i = actors.begin();
    while (i != actors.end())
    {
        if ((*i)->xVal() == x && (*i)->yVal() == y)
        {
            if ((*i)->vortexImpact())
            {
                int newX, newY;
                (*i)->teleportPos(x, y, newX, newY);
                (*i)->moveTo(newX, newY);
            }
        }
        i++;
    }
}

void StudentWorld::deleteVortex()
{
    vector<Actor*>::iterator i = actors.begin();
    while (i != actors.end())
    {
        if ((*i)->isVortex())
        {
            (*i)->setAlive(false);
        }
        i++;
    }
}
#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "Board.h"
#include <string>
#include <vector>

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp
class Actor;
class Player;
//class CoinSquare;
class Baddie;
class Vortex;

class StudentWorld : public GameWorld
{
public:
	StudentWorld(std::string assetPath);
	~StudentWorld() { cleanUp(); }
	std::string text();
	virtual int init();
	virtual int move();
	virtual void cleanUp();
	/* bool checkForSquare(int x, int y);*/
	 /*std::vector<Actor*>* getActors() { return &actors; }*/
	Board* getBoard() { return &m_board; }
	int playerOverlap(int x, int y);
	void setWalkingDir(int playerNum, int dir);
	
	int getPlayerCoins(int playerNum);
	void changePlayerCoins(int playerNum, int coins);

	int getPlayerStars(int playerNum);
	void changePlayerStars(int playerNum, int stars);
	
	void swapCoins();
	void swapStars();
	void swapAll();
	
	bool playerWaitingToRoll(int playerNum);

	bool getNewPlayer(int playerNum);

	void removeSquare(int x, int y, Baddie* b);

	void withdrawBank(int playerNum);
	void depositBank(int amt);

	void giveVortex(int playerNum);
	void shootVortex(int x, int y, int dir);
	void deleteVortex();

	void notNew(int playerNum);

	void teleport(int playerNum, int x, int y);
	void teleportBaddie(int x, int y);

	bool checkSquare(int x, int y);

	bool baddieIntersect(int x, int y);

private:
	std::vector<Actor*> actors;
	Player* m_peach;
	Player* m_yoshi;
	Vortex* m_vortex;
	Board m_board;
	int m_bank = 0;

};

#endif // STUDENTWORLD_H_

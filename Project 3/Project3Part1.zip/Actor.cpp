#include "Actor.h"
#include "StudentWorld.h"
#include <iostream>
#include <cstdlib>
using namespace std;

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

void Player::doSomething()
{
	if (m_waitingToRoll)
	{
		switch (getWorld()->getAction(1))
		{
		case ACTION_NONE:
			break;
		case ACTION_ROLL:
			m_die = randInt(1, 10);
			m_ticks_to_move = m_die * 8;
			m_waitingToRoll = false;
			break;
		/*case ACTION_LEFT:
			setDirection(left);
			moveTo(getX() - m_die, getY());
			break;
		case ACTION_RIGHT:
			setDirection(right);
			moveTo(getX() + m_die, getY());
			break;
		case ACTION_UP:
			moveTo(getX(), getY() - m_die);
			break;
		case ACTION_DOWN:
			moveTo(getX(), getY() + m_die);
			break;
		case ACTION_FIRE:
			break;*/
		default:
			return;
		}
	}
	else // walking
	{
		int newX, newY;
		if (m_walkingDirection == left || m_walkingDirection == right)
			getPositionInThisDirection(m_walkingDirection, SPRITE_WIDTH, newX, newY);
		else if (m_walkingDirection == up || m_walkingDirection == down)
			getPositionInThisDirection(m_walkingDirection, SPRITE_HEIGHT, newX, newY);
		if (!(isValidPos(newX, newY)))
		{
			//cout << "invalid" << endl;
			if (m_walkingDirection == right || m_walkingDirection == left)
			{
				if (isValidPos(getX(), getY() + SPRITE_HEIGHT))
				{
					cout << "here" << endl;
					m_walkingDirection = up;
					setDirection(right);
				}
				else if (isValidPos(getX(), getY() - SPRITE_HEIGHT))
				{
					m_walkingDirection = down;
					setDirection(right);
				}
			}
			else if (m_walkingDirection == up || m_walkingDirection == down)
			{
				if (isValidPos(getX() + SPRITE_WIDTH, getY()))
				{
					m_walkingDirection = right;
					setDirection(right);
				}
				else if (isValidPos(getX() - SPRITE_WIDTH, getY()))
				{
					m_walkingDirection = left;
					setDirection(left);
				}
			}
		}
		// move two pixels in walk direction
		moveAtAngle(m_walkingDirection, 2);
		if (getX() % SPRITE_WIDTH == 0 && getY() % SPRITE_HEIGHT == 0)
			m_die--;
		// decrement ticks_to_move count by 1
		m_ticks_to_move--;
		if (m_ticks_to_move == 0)
		{
			m_waitingToRoll = true;
		}
	}
}

void CoinSquare::doSomething()
{
	if (!getAlive())
	{
		return;
	}
}

bool Player::isValidPos(int x, int y)
{
	if (x < 0 || y < 0 || x > VIEW_WIDTH || y > VIEW_HEIGHT) { return false; }
	else if (x % SPRITE_WIDTH != 0 || y % SPRITE_HEIGHT != 0) { return false; }
	x /= SPRITE_WIDTH;
	y /= SPRITE_HEIGHT;
	if (getWorld()->getBoard()->getContentsOf(x, y) == Board::empty) { return false; }
	
	return true;
}
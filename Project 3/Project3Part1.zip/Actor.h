#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include <vector>
using namespace std;

class StudentWorld;

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class Actor : public GraphObject
{
public:
	Actor(StudentWorld* w, int imageID, int startX, int startY, int dir = right, int depth = 0, double size = 1.0) :
		GraphObject(imageID, startX, startY, dir, depth, size), m_world(w)
	{ }

	virtual void doSomething() = 0;
	StudentWorld* getWorld() { return m_world; }

private:
	StudentWorld* m_world;
};

class Player : public Actor
{
public:
	Player(StudentWorld* w, int imageID, int startX, int startY, int dir) :
		Actor(w, imageID, startX, startY, dir, 0, 1.0)
	{
		m_ticks_to_move = 0;
		m_walkingDirection = right;
		m_waitingToRoll = true;
		m_coins = 0;
		m_stars = 0;
		
	}
	bool waitingToRoll() { return m_waitingToRoll; }
	int getCoins() { return m_coins; }
	int getStars() { return m_stars; }
	int getDie() { return m_die; }
	bool getVortex() { return m_vortex; }

	void set_coins(int c) { m_coins = c; }

	virtual void doSomething ();
	bool isValidPos(int x, int y);

private:
	int m_ticks_to_move;
	bool m_waitingToRoll;
	bool m_side;
	int m_coins;
	int m_stars;
	int m_die = 0;
	int m_vortex;
	int m_walkingDirection;
};

class Peach : public Player
{
public:
	Peach(StudentWorld* w, int startX, int startY) : 
		Player(w, IID_PEACH, startX, startY, right)
	{}

private:
};

class Yoshi : public Player
{
public:
	Yoshi(StudentWorld* w, int startX, int startY) :
		Player(w, IID_YOSHI, startX, startY, right)
	{ }

private:
};

class CoinSquare : public Actor
{
public:
	CoinSquare(StudentWorld* w, int startX, int startY) :
		Actor(w, IID_BLUE_COIN_SQUARE, startX, startY, right, 1, 1.0)
	{}
	virtual void doSomething();
	bool getAlive() { return m_alive; }
	

private:
	bool m_alive;
};

#endif // ACTOR_H_
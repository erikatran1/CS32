#include "StudentWorld.h"
#include "GameConstants.h"
#include "Actor.h"
#include <string>
#include <sstream>
using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h, and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath)
{
    m_peach = nullptr;
    /*m_yoshi = nullptr;*/
    actors.clear();
}

int StudentWorld::init()
{
    string boardFile = "board0";
    ostringstream oss;
    string boardtxt = to_string(getBoardNumber()) + ".txt";
    oss << boardtxt;
    boardFile += oss.str();
    string board_file = assetPath() + boardFile;


    Board::LoadResult result = m_board.loadBoard(board_file);
    if (result == Board::load_fail_file_not_found)
    {
        cerr << "Could not find board01.txt data file\n";
        return GWSTATUS_BOARD_ERROR;
    }
    else if (result == Board::load_fail_bad_format)
    {
        cerr << "Your board was improperly formatted\n";
        return GWSTATUS_BOARD_ERROR;
    }
    else if (result == Board::load_success) {
        cerr << "Successfully loaded board\n";

        for (int i = 0; i < BOARD_WIDTH; i++)
        {
            for (int j = 0; j < BOARD_HEIGHT; j++)
            {
                int xVal = i * 16;
                int yVal = j * 16;
                
                Board::GridEntry ge = m_board.getContentsOf(i, j);
                switch (ge)
                {
                case Board::empty:
                    break;
                case Board::player:
                    m_peach = new Peach(this, xVal, yVal);
                    actors.push_back(new CoinSquare(this, xVal, yVal));
                    /*m_yoshi = new Yoshi(this, xVal, yVal);*/
                    break;
                case Board::blue_coin_square:
                    actors.push_back(new CoinSquare(this, xVal, yVal));
                    break;                    
                default:
                    break;
                }
            }
        }
    }

    startCountdownTimer(99);

	//startCountdownTimer(5);  // this placeholder causes timeout after 5 seconds
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    vector<Actor*>::iterator i = actors.begin();
    while (i != actors.end())
    {
        (*i)->doSomething();
        i++;
    }

    m_peach->doSomething();

    setGameStatText(text());
   
    if (timeRemaining() <= 0)
    {
        playSound(SOUND_GAME_FINISHED);
        //if ((m_yoshi->getStars() > m_peach->getStars()) || 
        //    ((m_yoshi->getStars() == m_peach->getStars()) && (m_yoshi->getCoins() > m_peach->getCoins()))) // yoshi won
        //{
        //    setFinalScore(m_yoshi->getStars(), m_yoshi->getCoins());
        //    return (GWSTATUS_YOSHI_WON);
        //}
        //if ((m_peach->getStars() > m_yoshi->getStars()) ||
        //    ((m_peach->getStars() == m_yoshi->getStars()) && (m_peach->getCoins() > m_yoshi->getCoins()))) // peach won
        {
            setFinalScore(m_peach->getStars(), m_peach->getCoins());
            return (GWSTATUS_PEACH_WON);
        }
    }

    return GWSTATUS_CONTINUE_GAME;


    // This code is here merely to allow the game to build, run, and terminate after you hit ESC.
    // Notice that the return value GWSTATUS_NOT_IMPLEMENTED will cause our framework to end the game.

    /*setGameStatText("Game will end in a few seconds");
    
    if (timeRemaining() <= 0)
		return GWSTATUS_NOT_IMPLEMENTED;
    
	return GWSTATUS_CONTINUE_GAME;*/
}

void StudentWorld::cleanUp()
{
    if (m_peach != nullptr)
    {
        delete m_peach;
        m_peach = nullptr;
    }
    /*if (m_yoshi != nullptr)
    {
        delete m_yoshi;
        m_yoshi = nullptr;
    }*/

    vector<Actor*>::iterator i = actors.begin();
    while (i != actors.end())
    {
        delete(*i);
        i = actors.erase(i);
    }
}

//  P1 Roll: 3 Stars: 2 $$: 15 | Time: 75 | Bank: 9 | P2 Roll: 0 Stars: 1 $$: 22 VOR
// Left P1 = peach
string StudentWorld::text()
{
    stringstream pDie, pStar, pCoin, time, bank/*, yDie, yStar, yCoin*/;
    string pDie_, pStar_, pCoin_, time_, bank_/*, yDie_, yStar_, yCoin_*/;
    pDie << m_peach->getDie();
    pDie >> pDie_;
    pStar << m_peach->getStars();
    pStar >> pStar_;
    pCoin << m_peach->getCoins();
    pCoin >> pCoin_;
    time << timeRemaining();
    time >> time_;
    bank << m_bank;
    bank >> bank_;
    /*yDie << m_yoshi->getDie();
    yDie >> yDie_;
    yStar << m_yoshi->getStars();
    yStar >> yStar_;
    yCoin << m_yoshi->getCoins();
    yCoin >> yCoin_;*/

    string text;

    text = "P1 Roll: " + pDie_ + " Stars: " + pStar_ + " $$: " + pCoin_;
    if (m_peach->getVortex())
    {
        text += " VOR";
    }        
    text += " | Time: " + time_ + " | Bank: " + bank_ /*+ " | P2 Roll: " + yDie_ + " Stars: " + yStar_ + " $$: " + yCoin_*/;
    /*if (m_yoshi->getVortex())
    {
        text += " VOR";
    }*/
    return text;
}
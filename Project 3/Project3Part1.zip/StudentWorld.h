#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "Board.h"
#include <string>
#include <vector>

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp
class Actor;
class Peach;
class Yoshi;
class CoinSquare;

class StudentWorld : public GameWorld
{
public:
  StudentWorld(std::string assetPath);
  ~StudentWorld() { cleanUp(); }
  std::string text();
  virtual int init();
  virtual int move();
  virtual void cleanUp();
  /*std::vector<Actor*>* getActors() { return &actors; }*/
  Board* getBoard() { return &m_board; }

private:
	std::vector<Actor*> actors;
	Peach* m_peach;
	/*Yoshi* m_yoshi;*/
	Board m_board;
	int m_bank = 0;
};

#endif // STUDENTWORLD_H_
#include "MovieDatabase.h"
#include "Movie.h"

#include <string>
#include <vector>
#include <fstream>
#include <cctype>
using namespace std;

MovieDatabase::MovieDatabase()
{ }

MovieDatabase::~MovieDatabase()
{
    for (auto movie : moviesToDelete)
    {
        delete movie;
    }
    moviesToDelete.clear();
}

bool MovieDatabase::load(const string& filename)
{
    ifstream userfile(filename);

    if (!userfile)
        return false;

    string id = "", title = "", release_year = "";
    string line;
    float rating;
    vector<string> directors, actors, genres;
    int linePerMovie = 1;
    Movie* movie;

    while (getline(userfile, line)) 
    {
        if (line.empty()) // new movie
        {
            linePerMovie = 1;
            directors.clear(); actors.clear(); genres.clear(); 
            id = ""; title = ""; release_year = "";
        }
        else 
        {
            if (linePerMovie == 1) // ID
            {
                for (int i = 0; i < line.size(); i++)
                {
                    if (isalpha(line[i]))
                        id += tolower(line[i]);
                    else
                        id += line[i];
                }
            }
           
            else if (linePerMovie == 2) // title
            {
                for (int i = 0; i < line.size(); i++)
                {
                    if (isalpha(line[i]))
                        title += tolower(line[i]);
                    else
                        title += line[i];
                }
            }
            
            else if (linePerMovie == 3) // release year
                release_year = line;
            
            else if (linePerMovie == 4) // directors
            {
                string temp = "";
                for (int i = 0; i < line.size(); i++) {
                    if (line[i] != ',')
                    {
                        if (isalpha(line[i]))
                            temp += tolower(line[i]);
                        else
                            temp += line[i];
                    }
                    else 
                    {
                        directors.push_back(temp);
                        temp = "";
                    }

                    if (i == line.size() - 1)
                    {
                        directors.push_back(temp);
                    }
                }
            }
            else if (linePerMovie == 5) // actors
            {
                string temp = "";
                for (int i = 0; i < line.size(); i++) {
                    if (line[i] != ',')
                    {
                        if (isalpha(line[i]))
                            temp += tolower(line[i]);
                        else
                            temp += line[i];
                    }
                    else 
                    {
                        actors.push_back(temp);
                        temp = "";
                    }

                    if (i == line.size() - 1)
                    {
                        actors.push_back(temp);
                    }
                }
            }
            else if (linePerMovie == 6) // genres
            {
                string temp = "";
                for (int i = 0; i < line.size(); i++) {
                    if (line[i] != ',')
                    {
                        if (isalpha(line[i]))
                            temp += tolower(line[i]);
                        else
                            temp += line[i];
                    }
                    
                    else 
                    {
                        genres.push_back(temp);
                        temp = "";
                    }
                    if (i == line.size() - 1)
                    {
                        genres.push_back(temp);
                    }
                }
            }
            else if (linePerMovie == 7) // rating
            {
                rating = stof(line);
                movie = new Movie(id, title, release_year, directors, actors, genres, rating);
                moviesToDelete.push_back(movie); // vector to delete later
                idToMovie.insert(id, movie);

                vector<string>::iterator it = directors.begin();
                for (; it < directors.end(); it++)
                { 
                    directorToMovies.insert(*it, movie);
                }
                for (it = actors.begin(); it < actors.end(); it++) 
                {
                    actorToMovies.insert(*it, movie);
                }
                for (it = genres.begin(); it < genres.end(); it++) 
                { 
                    genreToMovies.insert(*it, movie);
                }
            }
            else 
                return false; 

            linePerMovie += 1;
        }
    }
    return true;
}

Movie* MovieDatabase::get_movie_from_id(const string& id) const
{
    string idToLower = "";
    for (int i = 0; i < id.size(); i++)
    {
        idToLower += tolower(id[i]);
    }
    TreeMultimap<string, Movie*>::Iterator it = idToMovie.find(idToLower);
    if (it.is_valid()) 
        return it.get_value();
    
    return nullptr;
}

vector<Movie*> MovieDatabase::get_movies_with_director(const string& director) const
{
    string directorToLower = "";
    for (int i = 0; i < director.size(); i++)
    {
        directorToLower += tolower(director[i]);
    }
    TreeMultimap<string, Movie*>::Iterator it = directorToMovies.find(directorToLower);
    vector<Movie*> movies_with_director;
    while (it.is_valid()) {
        movies_with_director.push_back(it.get_value());
        it.advance();
    }
    return movies_with_director;
}

vector<Movie*> MovieDatabase::get_movies_with_actor(const string& actor) const
{
    string actorToLower = "";
    for (int i = 0; i < actor.size(); i++)
    {
        actorToLower += tolower(actor[i]);
    }
    TreeMultimap<string, Movie*>::Iterator it = actorToMovies.find(actorToLower);
    vector<Movie*> movies_with_actor;
    while (it.is_valid()) {
        movies_with_actor.push_back(it.get_value());
        it.advance();
    }
    return movies_with_actor;
}

vector<Movie*> MovieDatabase::get_movies_with_genre(const string& genre) const
{
    string genreToLower = "";
    for (int i = 0; i < genre.size(); i++)
    {
        genreToLower += tolower(genre[i]);
    }
    TreeMultimap<string, Movie*>::Iterator it = genreToMovies.find(genreToLower);
    vector<Movie*> movies_with_genre;
    while (it.is_valid()) {
        movies_with_genre.push_back(it.get_value());
        it.advance();
    }
    return movies_with_genre;
}
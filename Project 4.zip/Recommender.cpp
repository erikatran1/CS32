#include "Recommender.h"
#include "UserDatabase.h"
#include "MovieDatabase.h"
#include "User.h"
#include "Movie.h"

#include <unordered_map>
#include <map>
#include <string>
#include <iostream>
#include <vector>
#include <utility>
using namespace std;

Recommender::Recommender(const UserDatabase& user_database,
	const MovieDatabase& movie_database)
{
	udb = &user_database;
	mdb = &movie_database;
}

vector<MovieAndRank> Recommender::recommend_movies(const string& user_email, int movie_count)
{
	User* user = udb->get_user_from_email(user_email);
	vector<string> watchHistory = user->get_watch_history();
	vector<Movie*> watchedMovies; // store movies watched
	for (vector<string>::iterator it = watchHistory.begin(); it < watchHistory.end(); it++)
	{
		watchedMovies.push_back(mdb->get_movie_from_id(*it));
	}

	unordered_map<string, int> directorsToAmount;
	unordered_map<string, int> actorsToAmount;
	unordered_map<string, int> genresToAmount;
	for (vector<Movie*>::iterator mIt = watchedMovies.begin(); mIt != watchedMovies.end(); mIt++)
	{
		for (int i = 0; i != (*mIt)->get_directors().size(); i++)
		{
			string director = (*mIt)->get_directors()[i];
			unordered_map<string, int>::iterator dIt = directorsToAmount.find(director);
			if (dIt != directorsToAmount.end()) // store directors with amount
				directorsToAmount[director] += 20;
			else
				directorsToAmount[director] = 20;
		}
		for (int i = 0; i != (*mIt)->get_actors().size(); i++)
		{
			string actor = (*mIt)->get_actors()[i];
			unordered_map<string, int>::iterator aIt = actorsToAmount.find(actor);
			if (aIt != actorsToAmount.end()) // store actors with amount
				actorsToAmount[actor] += 30;
			else
				actorsToAmount[actor] = 30;
		}
		for (int i = 0; i != (*mIt)->get_genres().size(); i++)
		{
			string genre = (*mIt)->get_genres()[i];
			unordered_map<string, int>::iterator gIt = genresToAmount.find(genre);
			if (gIt != genresToAmount.end()) // store genres with amount
				genresToAmount[genre]++;
			else
				genresToAmount[genre] = 1;
		}
	}

	unordered_map<string, int> unwatchedMoviesScore;
	bool addToMap = true;
	unordered_map<string, int>::iterator it = directorsToAmount.begin();
	for (int i = 0; i != directorsToAmount.size(); i++) // iterate through all watched directors
	{
		vector<Movie*> directorMovies = mdb->get_movies_with_director(it->first);
		for (int j = 0; j != directorMovies.size(); j++) // iteate through all movies with director
		{
			string tempMovieID = directorMovies[j]->get_id();
			for (int k = 0; k != watchedMovies.size(); k++) // iterate through watched movies
			{
				string wmID = watchedMovies[k]->get_id();
				if (wmID == tempMovieID) // do not add movies that are watched
				{
					addToMap = false;
				}
			}
			if (addToMap)
			{
				unordered_map<string, int>::iterator d = unwatchedMoviesScore.find(tempMovieID);
				if (d != unwatchedMoviesScore.end())
					unwatchedMoviesScore[tempMovieID] += it->second;
				else
					unwatchedMoviesScore[tempMovieID] = it->second;
			}
			else
				addToMap = true;
		}
		it++;
	}
	
	it = actorsToAmount.begin();
	for (int i = 0; i != actorsToAmount.size(); i++) // iterate through all watched actors
	{
		vector<Movie*> actorMovies = mdb->get_movies_with_actor(it->first);
		for (int j = 0; j != actorMovies.size(); j++) // iterate through all movies with actor
		{
			string tempMovieID = actorMovies[j]->get_id();
			for (int k = 0; k != watchedMovies.size(); k++) // iterate through watched movies
			{
				string wmID = watchedMovies[k]->get_id();
				if (wmID == tempMovieID) // do not add movies that are watched
				{
					addToMap = false;
				}
			}
			if (addToMap)
			{
				unordered_map<string, int>::iterator d = unwatchedMoviesScore.find(tempMovieID);
				if (d != unwatchedMoviesScore.end())
					unwatchedMoviesScore[tempMovieID] += it->second;
				else
					unwatchedMoviesScore[tempMovieID] = it->second;
			}
			else
				addToMap = true;
		}
		it++;
	}
	
	it = genresToAmount.begin();
	for (int i = 0; i != genresToAmount.size(); i++) // iterate through all watched genres
	{
		vector<Movie*> genreMovies = mdb->get_movies_with_genre(it->first);
		for (int j = 0; j != genreMovies.size(); j++) // iterate through all movies with genre
		{
			string tempMovieID = genreMovies[j]->get_id();
			for (int k = 0; k != watchedMovies.size(); k++) // iterate through watched movies
			{
				string wmID = watchedMovies[k]->get_id();
				if (wmID == tempMovieID) // do not add movies that are watched
				{
					addToMap = false;
				}
			}
			if (addToMap)
			{
				unordered_map<string, int>::iterator d = unwatchedMoviesScore.find(tempMovieID);
				if (d != unwatchedMoviesScore.end())
					unwatchedMoviesScore[tempMovieID] += it->second;
				else
					unwatchedMoviesScore[tempMovieID] = it->second;
			}
			else
				addToMap = true;
		}
		it++;
	}

	unordered_map<string, int>::iterator it1 = unwatchedMoviesScore.begin();
	string maxID;
	int maxScore;
	vector<MovieAndRank> movieRanks;
	int num = 0;
	while (!unwatchedMoviesScore.empty())
	{
		// reset iterater and maximums to first value
		it1 = unwatchedMoviesScore.begin();
		maxID = it1->first;
		maxScore = it1->second;
		for (; it1 != unwatchedMoviesScore.end(); it1++)
		{
			if (it1->second > maxScore) // set maximum to highest score out of the two
			{
				maxID = it1->first;
				maxScore = it1->second;
			}
			else if (it1->second == maxScore) // if scores are the same
			{
				Movie* m1 = mdb->get_movie_from_id(it1->first);
				Movie* m2 = mdb->get_movie_from_id(maxID);
				if (m1->get_rating() > m2->get_rating()) // set maximum to one with higher rating
				{
					maxID = it1->first;
					maxScore = it1->second;
				}
				else if (m1->get_rating() == m2->get_rating()) // if ratings are the same
				{
					if (m1->get_title() < m2->get_title()) // set maximum to title that comes first
					{
						maxID = it1->first;
						maxScore = it1->second;
					}
				}
			}
		}
		if (num < movie_count) // push back maximum to new vector
		{
			MovieAndRank mr(maxID, maxScore);
			movieRanks.push_back(mr);
			num++;
		}
		else // if number of pushed back movies is greater than desired input
		{
			break;
		}
		
		unwatchedMoviesScore.erase(maxID); // erase from map
	}
	return movieRanks; // return vector
}
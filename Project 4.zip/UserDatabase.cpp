#include "UserDatabase.h"
#include "User.h"

#include <string>
#include <vector>
#include <fstream>
#include <iostream>
using namespace std;

UserDatabase::UserDatabase()
{ }

UserDatabase::~UserDatabase()
{
    for (auto user : usersToDelete)
    {
        delete user;
    }
    usersToDelete.clear();
}

bool UserDatabase::load(const string& filename)
{
    ifstream userfile(filename);
    if (!userfile) 
        return false; 

    string full_name, email, line;
    int numberOfMoviesWatchedByUser = 0;
    vector<string> watch_history;
    int linePerUser = 1;
    User* user;

    while (getline(userfile, line)) 
    {
        if (line.empty()) // new user
        {
            linePerUser = 1;
            watch_history.clear();
        }
        
        else {
            if (linePerUser == 1) // full name
                full_name = line;
            
            else if (linePerUser == 2) // email
                email = line;
            
            else if (linePerUser == 3) // number of movies watched
                numberOfMoviesWatchedByUser = stoi(line);
            
            else if (linePerUser > 3 && linePerUser <= numberOfMoviesWatchedByUser + 3) // watched movies
            {
                watch_history.push_back(line);
                if (numberOfMoviesWatchedByUser + 3 == linePerUser) 
                {
                    user = new User(full_name, email, watch_history);
                    usersToDelete.push_back(user); // vector to delete later
                    emailToUser.insert(email, user);
                }
            }

            else 
                return false; 

            linePerUser += 1;
        }
    }
    return true;
}

User* UserDatabase::get_user_from_email(const string& email) const
{
    TreeMultimap<string, User*>::Iterator it = emailToUser.find(email);
    if (it.is_valid()) 
        return it.get_value();
    
    return nullptr;
}
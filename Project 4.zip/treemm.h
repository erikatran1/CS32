#ifndef TREEMULTIMAP_INCLUDED
#define TREEMULTIMAP_INCLUDED

#include <vector>
#include <string>

template <typename KeyType, typename ValueType>
class TreeMultimap
{
public:
    class Iterator
    {
    public:
        Iterator()
        {
            index = -1;
        }

        Iterator(std::vector<ValueType>* v)
        {
            vals = v;
            index = 0;
        }

        ValueType& get_value() const
        {
            return vals->at(index);
        }

        bool is_valid() const
        {
            if (index == -1)
                return false;
            if (index >= vals->size())
                return false;
            return true;
        }

        void advance()
        {
            index += 1;
        }

    private:
        std::vector<ValueType>* vals;
        int index;
    };

    TreeMultimap()
    {
        m_root = nullptr;
    }

    ~TreeMultimap()
    {
        Node* cur = m_root;
        FreeTree(cur);
    }

    void insert(const KeyType& key, const ValueType& value)
    {
        if (m_root == nullptr)
        {
            m_root = new Node(key, value);
            return;
        }
        Node* cur = m_root;
        for (;;)
        {
            if (key == cur->key)
            {
                cur->values->push_back(value);
                return;
            }
            if (key < cur->key)
            {
                if (cur->left != nullptr)
                    cur = cur->left;
                else
                {
                    cur->left = new Node(key, value);
                    return;
                }
            }
            else if (key > cur->key)
            {
                if (cur->right != nullptr)
                    cur = cur->right;
                else
                {
                    cur->right = new Node(key, value);
                    return;
                }
            }
        }
    }

    Iterator find(const KeyType& key) const
    {
        Node* ptr = m_root;
        while (ptr != nullptr)
        {
            if (key == ptr->key)
                return Iterator(ptr->values);
            else if (key < ptr->key)
                ptr = ptr->left;
            else
                ptr = ptr->right;
        }
        return Iterator();
    }

private:
    struct Node
    {
        KeyType key;
        std::vector<ValueType>* values;
        Node(const KeyType& k, const ValueType& v) : key(k), left(nullptr), right(nullptr)
        {
            values = new std::vector<ValueType>;
                values->push_back(v);
        }
        Node* left;
        Node* right;
        ~Node()
        {
            delete values;
        }
    };
    Node* m_root;

    void FreeTree(Node* cur)
    {
        if (cur == nullptr)
            return;
        FreeTree(cur->left);
        FreeTree(cur->right);
        delete cur;
    }
};

#endif // TREEMULTIMAP_INCLUDED